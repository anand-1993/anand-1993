import json
import json
import pymysql
import sys


def lambda_handler(event, context):
    REGION = 'us-east-1'

    rds_host  = "makemytour-type.caijanknbu9e.us-east-1.rds.amazonaws.com"
    name = "root"
    password = "anand123"
    db_name = "makemytour"

    """
    This function fetches content from mysql RDS instance
    """
    result = []
    conn = pymysql.connect(host=rds_host, user=name, passwd=password, db=db_name, connect_timeout=5)
    with conn.cursor() as cur:
        cur.execute("""insert into mkpr_analytic_data (locations,type,price,Ipaddress,age,language,location_zip,browser,action,frome,Too,traffic_type,book_type) values('%s','%s',%s,'%s',%s,'%s', %s,'%s','%s','%s','%s','%s','%s')"""   % (event['locations'], event['type'], event['price'], event['Ipaddress'], event['age'],event['language'], event['location_zip'], event['browser'], event['action'], event['frome'], event['Too'],event['traffic_type'], event['book_type']))
        cur.execute("""select * from mkpr_analytic_data""")
        conn.commit()
        cur.close()
        for row in cur:
            result.append(list(row))
        print("Data from RDS...")
        print (result)
    return {
        'statusCode': 200,
        'body': json.dumps('Data Inserted Successfuly')
    }
