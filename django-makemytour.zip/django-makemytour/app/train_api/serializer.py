from rest_framework import serializers
from .models import Passenger, Station, Ticket, Train, TrainStatus

'''class passengerserializer(serializers.ModelSerializer):
    #passenger_id = serializers.AutoField(primary_key=True)
    first_name = serializers.CharField(max_length=45)
    last_name = serializers.CharField(max_length=45)
    birth_date = serializers.DateField()
    age = serializers.IntegerField()
    gender = serializers.CharField(max_length=45)
    id_type = serializers.CharField(max_length=45)
    city = serializers.CharField(max_length=45)

    class Meta:
        model = Passenger
        fields = '__all__'

    def create(self, data):
        return Passenger.objects.create(**data)

    def update(self, instance, data):
        instance.first_name = data.get("first_name", instance.first_name)
        instance.last_name = data.get("last_name", instance.last_name)
        instance. birth_date = data.get(" birth_date", instance.birth_date)
        instance. age = data.get(" age", instance.age)
        instance. gender = data.get(" gender", instance.gender)
        instance.id_type = data.get("id_type", instance.id_type)
        instance. city = data.get(" city ", instance.city)
        instance.save()
        return instance


    def __str__(self):
        return self.passenger_id'''

#serializer for Passenger model::
class passengerserializer(serializers.ModelSerializer):
    class Meta:
        model = Passenger
        fields = '__all__'


#serializer for station model::

class stationserializer(serializers.ModelSerializer):
       class Meta:
           model = Station
           fields = '__all__'

#serializer for ticket model::

class ticketserializer(serializers.ModelSerializer):
    class Meta:
        model = Ticket
        fields = '__all__'


#serializer for train model::

class trainserializer(serializers.ModelSerializer):
    class Meta:
        model = Train
        fields = '__all__'

#serializer for trainstatus::

class trainstatusserializer(serializers.ModelSerializer):
    class Meta:
        model = TrainStatus
        fields = '__all__'








