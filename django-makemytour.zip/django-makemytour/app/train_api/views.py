from django.shortcuts import render

# Create your views here.

from django.shortcuts import render
from rest_framework.response import Response
from rest_framework. decorators import api_view
from .models import *
from .serializer import *
from rest_framework.generics import ListAPIView

# Create your views here.

'''#class and filter example:
class passengerlist(ListAPIView):
    queryset = Passenger.objects.filter(last_name='Shende')
    serializer_class = passengerserializer'''

#views for passengerserializer::
@api_view(['GET'])
def passenger_list(request):
    passengers = Passenger.objects.all()
    serializer= passengerserializer(passengers, many=True)
    return Response(serializer.data)

@api_view(['POST'])
def passenger_create(request):
    serializer = passengerserializer(data=request.data)
    if serializer.is_valid():
        serializer.save()
        return Response(serializer.data)
    else:
        return Response(serializer.errors)

@api_view(['GET', 'PUT', 'DELETE'])
def passenger_update(request, pk):
    passengers = Passenger.objects.get(passenger_id=pk)
    if request.method == 'GET':

        serializer = passengerserializer(passengers, many=False)
        return Response(serializer.data)


    if request.method == "PUT":
        passengers = Passenger.objects.get(passenger_id=pk)
        serializer = passengerserializer(passengers, data=request.data)

        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        else:
            return Response(serializer.errors)

    if request.method == "DELETE":
        passengers.delete()
        return Response({
            'delete': True
        })


#views for stationserializer::

@api_view(['GET'])
def station_list(request):
    stations = Station.objects.all()
    serializer = stationserializer(stations, many=True)
    return Response(serializer.data)


@api_view(['POST'])
def station_create(request):
    serializer = stationserializer(data=request.data)
    if serializer.is_valid():
        serializer.save()
        return Response(serializer.data)
    else:
        return Response(serializer.errors)


@api_view(['GET', 'PUT', 'DELETE'])
def station_update(request, pk):
    stations = Station.objects.get(Station_id=pk)
    if request.method == 'GET':
        serializer = stationserializer(stations, many=False)
        return Response(serializer.data)

    if request.method == "PUT":
        serializer = stationserializer(stations, data=request.data)
        stations = Station.objects.get(Station_id=pk)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        else:
            return Response(serializer.errors)

    if request.method == "DELETE":
        stations.delete()
        return Response({
            'delete': True
        })

#view for ticket serializer::
@api_view(['GET'])
def ticket_list(request):
    tickets = Ticket.objects.all()
    serializer = ticketserializer(tickets, many=True)
    return Response(serializer.data)


@api_view(['POST'])
def ticket_create(request):
    serializer = ticketserializer(data=request.data)
    if serializer.is_valid():
        serializer.save()
        return Response(serializer.data)
    else:
        return Response(serializer.errors)


@api_view(['GET', 'PUT', 'DELETE'])
def ticket_update(request, pk):
    tickets = Ticket.objects.get(ticket_id=pk)
    if request.method == 'GET':
        serializer = ticketserializer(tickets, many=False)
        return Response(serializer.data)

    if request.method == "PUT":
        serializer = ticketserializer(tickets, data=request.data)
        tickets = Ticket.objects.get(ticket_id=pk)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        else:
            return Response(serializer.errors)

    if request.method == "DELETE":
        tickets.delete()
        return Response({
            'delete': True
        })

#view for trainserializer::
@api_view(['GET'])
def train_list(request):
    trains = Train.objects.all()
    serializer = trainserializer(trains, many=True)
    return Response(serializer.data)


@api_view(['POST'])
def train_create(request):
    serializer = trainserializer(data=request.data)
    if serializer.is_valid():
        serializer.save()
        return Response(serializer.data)
    else:
        return Response(serializer.errors)


@api_view(['GET', 'PUT', 'DELETE'])
def train_update(request, pk):
    trains = Train.objects.get(train_id=pk)
    if request.method == 'GET':
        serializer = trainserializer(trains, many=False)
        return Response(serializer.data)

    if request.method == "PUT":
        serializer = trainserializer(trains, data=request.data)
        trains = Train.objects.get(train_id=pk)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        else:
            return Response(serializer.errors)

    if request.method == "DELETE":
        trains.delete()
        return Response({
            'delete': True
        })


#view for trainstatusserializer::

@api_view(['GET'])
def trainstatus_list(request):
    trainstatuss = TrainStatus.objects.all()
    serializer = trainstatusserializer(trainstatuss, many=True)
    return Response(serializer.data)


@api_view(['POST'])
def trainstatus_create(request):
    serializer = trainstatusserializer(data=request.data)
    if serializer.is_valid():
        serializer.save()
        return Response(serializer.data)
    else:
        return Response(serializer.errors)


@api_view(['GET', 'PUT', 'DELETE'])
def trainstatus_update(request, pk):
    trainstatuss = TrainStatus.objects.get(train_status_id=pk)
    if request.method == 'GET':
        serializer = trainstatusserializer(trainstatuss, many=False)
        return Response(serializer.data)

    if request.method == "PUT":
        serializer = trainstatusserializer(trainstatuss, data=request.data)
        trainstatuss = TrainStatus.objects.get(train_status_id=pk)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        else:
            return Response(serializer.errors)

    if request.method == "DELETE":
        trainstatuss.delete()
        return Response({
            'delete': True
        })




'''********** code using JsonResponse ************

from django.shortcuts import render
from django.http import JsonResponse
from train_api.models import Passenger
from train_api.serializer import passengerserializer

# Create your views here.
def passenger_list(request):
    passengers = Passenger.objects.all()
    passengers_py = list(passengers.values())
    return JsonResponse({
        "passengers": passengers_py
    })
'''

