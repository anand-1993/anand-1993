from django.apps import AppConfig


class TrainApiConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'train_api'
