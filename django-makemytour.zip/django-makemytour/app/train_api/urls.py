from django.contrib import admin
from django.urls import path
from .views import *

#from train_api import views


urlpatterns = [
   #path("", views.passengerlist.as_view()),
   path('passenger_create/', passenger_create),
   path('passenger_list/', passenger_list),
   path('passenger_update/<int:pk>/', passenger_update),
   path('station_create/', station_create),
   path('station_list/', station_list),
   path('station_update/<int:pk>/', station_update),
   path('ticket_create/', ticket_create),
   path('ticket_list/', ticket_list),
   path('ticket_update/<int:pk>/', ticket_update),
   path('train_create/', train_create),
   path('train_list/', train_list),
   path('train_update/<int:pk>/', train_update),
   path('trainstatus_create/', trainstatus_create),
   path('trainstatus_list/', trainstatus_list),
   path('trainstatus_update/<int:pk>/', trainstatus_update),
]
