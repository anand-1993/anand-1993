from django.db import models

# Create your models here.

class Passenger(models.Model):
    passenger_id = models.AutoField(primary_key=True)
    first_name = models.CharField(max_length=45)
    last_name = models.CharField(max_length=45)
    birth_date = models.DateField()
    age = models.IntegerField()
    gender = models.CharField(max_length=45)
    id_type = models.CharField(max_length=45)
    city = models.CharField(max_length=45)

    class Meta:
        managed = True
        db_table = 'passenger'

    def __str__(self):
        return self.first_name

class Station(models.Model):
    station_id = models.AutoField(primary_key=True)
    station_name = models.CharField(max_length=45)
    station_city = models.CharField(max_length=45)

    class Meta:
        managed = True
        db_table = 'station'

    def __str__(self):
        return self.station_name


class Ticket(models.Model):
    ticket = models.OneToOneField(Passenger, models.DO_NOTHING, primary_key=True)
    ticket_time = models.TimeField()
    sources = models.CharField(max_length=45)
    destination = models.CharField(max_length=45)
    date_issued = models.DateField(blank=True, null=True)
    single_or_return = models.CharField(max_length=45)
    fare = models.IntegerField()
    passenger_id = models.IntegerField()

    class Meta:
        managed = True
        db_table = 'ticket'
        unique_together = (('ticket', 'passenger_id'),)

    def __str__(self):
        return self.ticket


class Train(models.Model):
    train_id = models.AutoField(primary_key=True)
    train_name = models.CharField(max_length=45)
    train_type = models.CharField(max_length=45)
    date = models.DateTimeField()
    source = models.CharField(max_length=50)
    destination = models.CharField(max_length=45)
    arrival_time = models.TimeField()
    departure_time = models.TimeField(blank=True, null=True)
    seats_available = models.IntegerField()
    station_id_fk = models.ForeignKey(Station, models.DO_NOTHING, db_column='station_id_fk', blank=True, null=True)
    train_status_id_fk = models.ForeignKey('TrainStatus', models.DO_NOTHING, db_column='train_status_id_fk', blank=True, null=True)
    ticket_id_fk = models.ForeignKey(Ticket, models.DO_NOTHING, db_column='ticket_id_fk', blank=True, null=True)

    class Meta:
        managed = True
        db_table = 'train'

    def __str__(self):
        return self.train_id

class TrainStatus(models.Model):
    train_status_id = models.AutoField(primary_key=True)
    train_name = models.CharField(max_length=50)
    train_type = models.CharField(max_length=20)
    available_seat = models.IntegerField()
    booked_seat = models.IntegerField()
    waiting_seat = models.IntegerField()

    class Meta:
        managed = True
        db_table = 'train_status'

    def __str__(self):
        return self.train_status_id
