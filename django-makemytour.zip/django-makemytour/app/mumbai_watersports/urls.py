from django.test import TestCase

# Create your tests here.
from django.urls import path
# from django.contrib import admin
from .views import *


urlpatterns = [
    # path('watersports/',views.watersports_places),
    path('watersports/', watersports_places.as_view()),
    path('watersports_update/<int:pk>/', watersports_update.as_view())
]
