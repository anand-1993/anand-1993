from django.shortcuts import render
from rest_framework.response import Response
from rest_framework import status
from .models import monuments
from .serializers import monumentsSerializer
from rest_framework.renderers import JSONRenderer
from django.http import HttpResponse,JsonResponse
from rest_framework.response import Response
from rest_framework import status
from .models import monuments
from .serializers import monumentsSerializer
from rest_framework.renderers import JSONRenderer
from django.http import HttpResponse,JsonResponse
from rest_framework.decorators import api_view ,APIView



# @api_view(['GET'])
# def monument_places(request):
#     place= monuments.objects.all()
#     serializer = monumentsSerializer(place,many=True)
#     return JsonResponse(serializer.data,safe=False)
#

class monument_places(APIView):
    def get(self,request):
        info = monuments.objects.all()

        serializer = monumentsSerializer(info, many=True)
        return Response(serializer.data)

    def post(self, request):
        serializer = monumentsSerializer(data=request.data)

        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)

        else:
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class monuments_update(APIView):

    def get(self, request, pk):
        try:
            monuments_id = monuments.objects.get(pk=pk)
        except:
            return Response({"Error": "monuments is not exist"}, status=status.HTTP_404_NOT_FOUND)
        serializer = monumentsSerializer(monuments_id)
        return Response(serializer.data)


    def put(self,request, pk):
        monuments_id = monuments.objects.get(pk=pk)
        serializer = monumentsSerializer(monuments_id, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


    def delete(self,request,pk):
        monuments_id = monuments.objects.get(pk=pk)
        monuments_id.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)
