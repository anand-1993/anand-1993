from django.apps import AppConfig


class MonumentsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'mumbai_monuments'
