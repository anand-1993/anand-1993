from rest_framework import serializers
from .models import *

from .models import *

class monumentsSerializer(serializers.ModelSerializer):
    # places = serializers.CharField(max_length=100)
    # Idmonuments = serializers.IntegerField()
    class Meta:
        model = monuments
        fields = '__all__'


