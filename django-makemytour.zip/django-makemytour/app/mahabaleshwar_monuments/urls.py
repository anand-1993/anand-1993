from django.test import TestCase

# Create your tests here.
from django.urls import path
# from django.contrib import admin
from .views import *

urlpatterns = [
    # path('monuments/',views.monument_places),
    path('monuments/',monument_places.as_view()),
    path('monuments_update/<int:pk>/',monuments_update.as_view())
]