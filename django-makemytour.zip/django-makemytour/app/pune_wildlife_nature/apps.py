from django.apps import AppConfig


class WildlifeNatureConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'pune_wildlife_nature'
