from django.test import TestCase

# Create your tests here.
from django.urls import path
from .views import *


urlpatterns = [
    # path('monuments/',views.monument_places),
    path('spiritual/',spiritual_places.as_view()),
    path('spiritual_update/<int:pk>/',spiritual_update.as_view())
]