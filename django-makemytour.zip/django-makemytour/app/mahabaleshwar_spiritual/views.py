from django.shortcuts import render
from rest_framework.response import Response
from rest_framework import status
from .models import spiritual
from .serializers import spiritualSerializer
from rest_framework.renderers import JSONRenderer
from rest_framework.response import Response
from rest_framework import status
from .models import spiritual
from .serializers import spiritualSerializer
from rest_framework.renderers import JSONRenderer
from django.http import HttpResponse,JsonResponse
from rest_framework.decorators import api_view ,APIView

# @api_view(['GET'])
# def spiritual_places(request):
#     place= spiritual.objects.all()
#     serializer = spiritualSerializer(place,many=True)
#     return JsonResponse(serializer.data,safe=False)
class spiritual_places(APIView):
    def get(self,request):
        info = spiritual.objects.all()

        serializer = spiritualSerializer(info, many=True)
        return Response(serializer.data)

    def post(self, request):
        serializer = spiritualSerializer(data=request.data)

        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)

        else:
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class spiritual_update(APIView):

    def get(self, request, pk):
        try:
            spiritual_id = spiritual.objects.get(pk=pk)
        except:
            return Response({"Error": "spiritual is not exist"}, status=status.HTTP_404_NOT_FOUND)
        serializer = spiritualSerializer(spiritual_id)
        return Response(serializer.data)


    def put(self,request, pk):
        spiritual_id = spiritual.objects.get(pk=pk)
        serializer = spiritualSerializer(spiritual_id, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


    def delete(self,request,pk):
        spiritual_id = spiritual.objects.get(pk=pk)
        spiritual_id.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)
