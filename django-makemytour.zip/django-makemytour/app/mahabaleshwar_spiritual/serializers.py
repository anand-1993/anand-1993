from rest_framework import serializers
from .models import *


from .models import *

class spiritualSerializer(serializers.ModelSerializer):
    # places = serializers.CharField(max_length=100)
    # Idspiritual = serializers.IntegerField()

    class Meta:
        model = spiritual
        fields = '__all__'
