from django.contrib import admin
from .models import spiritual

admin.site.register(spiritual)