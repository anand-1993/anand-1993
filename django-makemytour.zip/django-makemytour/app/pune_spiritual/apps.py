from django.apps import AppConfig


class SpiritualConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'pune_spiritual'
