from rest_framework.response import Response
from rest_framework import status
from .models import *
from .serializer import *
from rest_framework.decorators import *
from django.shortcuts import render
from django.http import *
from rest_framework.filters import SearchFilter
from rest_framework.generics import ListAPIView


class location_list(APIView):
    def get(self,request):
        info = Location.objects.all()

        serializer = LocationSerializer(info, many=True)
        return Response(serializer.data)

    def post(self, request):
        serializer = LocationSerializer(data=request.data)

        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)

        else:
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class location_update(APIView):

    def get(self, request, pk):
        try:
            location_id = Location.objects.get(pk=pk)
        except:
            return Response({"Error": "Location is not exist"}, status=status.HTTP_404_NOT_FOUND)
        serializer = LocationSerializer(location_id)
        return Response(serializer.data)


    def put(self,request, pk):
        location_id = Location.objects.get(pk=pk)
        serializer = LocationSerializer(location_id, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


    def delete(self,request,pk):
        location_id = Location.objects.get(pk=pk)
        location_id.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)


class hotel_list(APIView):
    def get(self,request):
        info = Hotel.objects.all()
        serializer = HotelSerializer(info, many=True)
        return Response(serializer.data)

    def post(self, request):
        serializer = HotelSerializer(data=request.data)

        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)

        else:
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class hotel_update(APIView):

    def get(self, request, pk):
        try:
            hotel_id = Hotel.objects.get(pk=pk)
        except:
            return Response({"Error": "Hotel is not exist"}, status=status.HTTP_404_NOT_FOUND)
        serializer = HotelSerializer(hotel_id)
        return Response(serializer.data)


    def put(self,request, pk):
        hotel_id = Hotel.objects.get(pk=pk)
        serializer = HotelSerializer(hotel_id, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


    def delete(self,request,pk):
        hotel_id = Hotel.objects.get(pk=pk)
        hotel_id.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)


class guest_list(APIView):
    def get(self,request):
        info = Guests.objects.all()
        serializer = GuestsSerializer(info, many=True)
        return Response(serializer.data)

    def post(self, request):
        serializer = GuestsSerializer(data=request.data)

        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)

        else:
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class guest_update(APIView):

    def get(self, request, pk):
        try:
            guest_id = Guests.objects.get(pk=pk)
        except:
            return Response({"Error": "Guests is not exist"}, status=status.HTTP_404_NOT_FOUND)
        serializer = GuestsSerializer(guest_id)
        return Response(serializer.data)


    def put(self,request, pk):
        guest_id = Guests.objects.get(pk=pk)
        serializer = GuestsSerializer(guest_id, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


    def delete(self,request,pk):
        guest_id = Guests.objects.get(pk=pk)
        guest_id.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)


class address_list(APIView):
    def get(self,request):
        info = HotelAddresses.objects.all()
        serializer = HotelAddressesSerializer(info, many=True)
        return Response(serializer.data)

    def post(self, request):
        serializer = HotelAddresses(data=request.data)

        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)

        else:
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class address_update(APIView):

    def get(self, request, pk):
        try:
            address_id = HotelAddresses.objects.get(pk=pk)
        except:
            return Response({"Error": "Address is not exist"}, status=status.HTTP_404_NOT_FOUND)
        serializer = HotelAddressesSerializer(address_id)
        return Response(serializer.data)


    def put(self,request, pk):
        address_id = HotelAddresses.objects.get(pk=pk)
        serializer = HotelAddressesSerializer(address_id, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def delete(self,request,pk):
        address_id = HotelAddresses.objects.get(pk=pk)
        address_id.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)

class booking_list(APIView):
    def get(self,request):
        info = bookings.objects.all()
        serializer = bookingsSerializer(info, many=True)
        return Response(serializer.data)

    def post(self,request):
        serializer = bookingsSerializer(data=request.data)

        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)

        else:
            return Response(serializer.errors, status= status.HTTP_400_BAD_REQUEST)

class booking_update(APIView):

    def get(self, request, pk):
        try:
            booking_id = bookings.objects.get(pk=pk)
        except:
            return Response({"Error": "Booking is not exist"}, status=status.HTTP_404_NOT_FOUND)
        serializer = bookingsSerializer(booking_id)
        return Response(serializer.data)

    def put(self,request, pk):
        booking_id = bookings.objects.get(pk=pk)
        serializer = bookingsSerializer(booking_id, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


    def delete(self,request,pk):
        booking_id = bookings.objects.get(pk=pk)
        booking_id.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)

class hotel_service_list(APIView):
    def get(self,request):
        info = HotelServices.objects.all()
        serializer = HotelServicesSerializer(info, many=True)
        return Response(serializer.data)

    def post(self,request):
        serializer = HotelServicesSerializer(data=request.data)

        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)

        else:
            return Response(serializer.errors, status= status.HTTP_400_BAD_REQUEST)

class hotel_service_update(APIView):

    def get(self, request, pk):
        try:
            hotel_sersvice_id = HotelServices.objects.get(pk=pk)
        except:
            return Response({"Error": "Service is not exist"}, status=status.HTTP_404_NOT_FOUND)
        serializer = HotelServicesSerializer(hotel_sersvice_id)
        return Response(serializer.data)

    def put(self,request, pk):
        hotel_sersvice_id = HotelServices.objects.get(pk=pk)
        serializer = HotelServicesSerializer(hotel_sersvice_id, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


    def delete(self,request,pk):
        hotel_sersvice_id = bookings.objects.get(pk=pk)
        hotel_sersvice_id.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)


class room_type_list(APIView):
    def get(self,request):
        info = RoomType.objects.all()
        serializer = RoomTypeSerializer(info, many=True)
        return Response(serializer.data)

    def post(self,request):
        serializer = RoomTypeSerializer(data=request.data)

        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)

        else:
            return Response(serializer.errors, status= status.HTTP_400_BAD_REQUEST)

class room_type_update(APIView):

    def get(self, request, pk):
        try:
            room_type_id = RoomType.objects.get(pk=pk)
        except:
            return Response({"Error": "Room_Type  is not exist"}, status=status.HTTP_404_NOT_FOUND)
        serializer = RoomTypeSerializer(room_type_id)
        return Response(serializer.data)

    def put(self,request, pk):
        room_type_id = RoomType.objects.get(pk=pk)
        serializer = RoomTypeSerializer(room_type_id, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


    def delete(self,request,pk):
        room_type_id = RoomType.objects.get(pk=pk)
        room_type_id.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)


class room_list(APIView):
    def get(self,request):
        info = Rooms.objects.all()
        serializer = RoomsSerializer(info, many=True)
        return Response(serializer.data)

    def post(self,request):
        serializer = RoomsSerializer(data=request.data)

        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)

        else:
            return Response(serializer.errors, status= status.HTTP_400_BAD_REQUEST)

class room_update(APIView):

    def get(self, request, pk):
        try:
            room_id = Rooms.objects.get(pk=pk)
        except:
            return Response({"Error": "Room  is not exist"}, status=status.HTTP_404_NOT_FOUND)
        serializer = RoomsSerializer(room_id)
        return Response(serializer.data)

    def put(self,request, pk):
        room_id = Rooms.objects.get(pk=pk)
        serializer = RoomsSerializer(room_id, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


    def delete(self,request,pk):
        room_id = Rooms.objects.get(pk=pk)
        room_id.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)


class room_rate_discount_list(APIView):
    def get(self,request):
        info = RoomRateDiscount.objects.all()
        serializer = RoomRateDiscountSerializer(info, many=True)
        return Response(serializer.data)

    def post(self,request):
        serializer = RoomRateDiscountSerializer(data=request.data)

        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)

        else:
            return Response(serializer.errors, status= status.HTTP_400_BAD_REQUEST)

class room_rate_discount_update(APIView):

    def get(self, request, pk):
        try:
            rate_discount = RoomRateDiscount.objects.get(pk=pk)
        except:
            return Response({"Error": "Room_rate_discount  is not exist"}, status=status.HTTP_404_NOT_FOUND)
        serializer = RoomsSerializer(rate_discount)
        return Response(serializer.data)

    def put(self,request, pk):
        rate_discount = RoomRateDiscount.objects.get(pk=pk)
        serializer = RoomRateDiscountSerializer(rate_discount, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


    def delete(self,request,pk):
        rate_discount = RoomRateDiscount.objects.get(pk=pk)
        rate_discount.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)

class hotel_service_used_list(APIView):
    def get(self,request):
        info = HotelServicesUsedByGuests.objects.all()
        serializer = HotelServicesUsedByGuestsSerializer(info, many=True)
        return Response(serializer.data)

    def post(self,request):
        serializer = HotelServicesUsedByGuestsSerializer(data=request.data)

        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)

        else:
            return Response(serializer.errors, status= status.HTTP_400_BAD_REQUEST)

class  hotel_service_use_update(APIView):

    def get(self, request, pk):
        try:
            rate_discount = HotelServicesUsedByGuests.objects.get(pk=pk)
        except:
            return Response({"Error": " hotel_sersvice_use_id  is not exist"}, status=status.HTTP_404_NOT_FOUND)
        serializer = HotelServicesUsedByGuestsSerializer(rate_discount)
        return Response(serializer.data)

    def put(self,request, pk):
        hotel_sersvice_use_id = HotelServicesUsedByGuests.objects.get(pk=pk)
        serializer = HotelServicesUsedByGuestsSerializer(hotel_sersvice_use_id, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


    def delete(self,request,pk):
        hotel_sersvice_use_id = HotelServicesUsedByGuests.objects.get(pk=pk)
        hotel_sersvice_use_id.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)


class room_rate_discount_list(APIView):
    def get(self,request):
        info = RoomRateDiscount.objects.all()
        serializer = RoomRateDiscountSerializer(info, many=True)
        return Response(serializer.data)

    def post(self,request):
        serializer = RoomRateDiscountSerializer(data=request.data)

        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)

        else:
            return Response(serializer.errors, status= status.HTTP_400_BAD_REQUEST)

class room_rate_discount_update(APIView):

    def get(self, request, pk):
        try:
            rate_discount = RoomRateDiscount.objects.get(pk=pk)
        except:
            return Response({"Error": "Room_rate_discount  is not exist"}, status=status.HTTP_404_NOT_FOUND)
        serializer = RoomsSerializer(rate_discount)
        return Response(serializer.data)

    def put(self,request, pk):
        rate_discount = RoomRateDiscount.objects.get(pk=pk)
        serializer = RoomRateDiscountSerializer(rate_discount, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


    def delete(self,request,pk):
        rate_discount = RoomRateDiscount.objects.get(pk=pk)
        rate_discount.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)

class room_booked_list(APIView):
    def get(self,request):
        info = RoomsBooked.objects.all()
        serializer = RoomsBookedSerializer(info, many=True)
        return Response(serializer.data)

    def post(self,request):
        serializer = RoomsBookedSerializer(data=request.data)

        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)

        else:
            return Response(serializer.errors, status= status.HTTP_400_BAD_REQUEST)

class  room_booked_update(APIView):

    def get(self, request, pk):
        try:
            room_booked_id = RoomsBooked.objects.get(pk=pk)
        except:
            return Response({"Error": " The Rooms You enter  are not exist"}, status=status.HTTP_404_NOT_FOUND)
        serializer = RoomsBookedSerializer(room_booked_id)
        return Response(serializer.data)

    def put(self,request, pk):
        room_booked_id = RoomsBooked.objects.get(pk=pk)
        serializer = RoomsBookedSerializer(room_booked_id, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def delete(self,request,pk):
        room_booked_id = RoomsBooked.objects.get(pk=pk)
        room_booked_id.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)

#
# class journey_list(APIView):
#     def get(self,request):
#         info = Location.objects.get('city_name0')
#
#         serializer = guest_journey_details(info,many=True)
#
#         return Response(serializer.data)



# Create your views here.

# def booking_list(request):
#     booking_data = bookings.objects.all()  # complex_data
#     python_datatype = list(booking_data.values()) # python DS
#     return  JsonResponse({"Booking_info": python_datatype})   # http view response
#
#
# @api_view(['GET'])
# def Bookings(request):
#     info = bookings.objects.all()  # complex data
#     serializer = bookingsSerializer(info, many=True)
#     return  Response(serializer.data)
#
#
#
# @api_view(['GET'])
# def guests(request):
#     info = Guests.objects.all()
#     serializer = GuestsSerializer(info, many=True)
#     return  Response(serializer.data)
#
#
# @api_view(['POST'])
# def AddGuest(request):
#     serializer= GuestsSerializer(data=request.data)
#
#
#     if serializer.is_valid():
#         serializer.save()
#         return Response(serializer.data)
#
#     else:
#         return Response(serializer.errors)
#
#
# @api_view(['GET',   'PUT',   'DELETE'])
# def booking_pk(request, pk):
#     try:
#         booking_id = bookings.objects.get(pk=pk)
#     except:
#         return Response({"Error" : "Booking is not exist"}, status=status.HTTP_404_NOT_FOUND)
#     if request.method == 'GET' :
#         serializer = bookingsSerializer(booking_id)
#         return Response(serializer.data)
#
#     if request.method == 'PUT':
#             serializer = bookingsSerializer(booking_id,data=request.data )
#             if serializer.is_valid():
#                 serializer.save()
#                 return Response(serializer.data)
#             return Response(serializer.errors, status = status.HTTP_400_BAD_REQUEST)
#
#     if request.method == 'DELETE':
#            booking_id.delete()
#            return Response(status=status.HTTP_204_NO_CONTENT)
#
#
#
# from rest_framework.views import APIView
#
# class guest_search(ListAPIView):
#     queryset = Guests.objects.all()
#     serializer_class = GuestsSerializer
#     filter_backends = [SearchFilter]
#     search_fields = ['guest_contact_number']

#     bookingss = list(info.values())
#     return  JsonResponse({
#         'Bookings' : bookingss
#     })

