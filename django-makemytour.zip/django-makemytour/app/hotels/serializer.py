from rest_framework import serializers
# from .models import bookings,Guests,Hotel,HotelServices,HotelServicesUsedByGuests,HotelAddresses,Location,Rooms,RoomsBooked,RoomType,RoomRateDiscount
from .models import *
from django.core.exceptions import ValidationError
from django.forms import ValidationError


class HotelServicesUsedByGuestsSerializer(serializers.ModelSerializer):
    class Meta:
        model = HotelServicesUsedByGuests
        fields = '__all__'

class RoomRateDiscountSerializer(serializers.ModelSerializer):
    class Meta:
        model = RoomRateDiscount
        fields = '__all__'


class RoomsBookedSerializer(serializers.ModelSerializer):
    class Meta:
        model = RoomsBooked
        fields = '__all__'

class RoomsSerializer(serializers.ModelSerializer):
# room_booked_user = RoomsBookedSerializer(many=True,read_only=False)
    class Meta:
        model = Rooms
        fields = '__all__'

class RoomTypeSerializer(serializers.ModelSerializer):
# rate_discount_user = RoomRateDiscountSerializer(many=True,read_only=False)
#  room_user1 = RoomsSerializer(many=True,read_only=False)
    class Meta:
        model = RoomType
        fields = '__all__'

class HotelServicesSerializer(serializers.ModelSerializer):
# booking_id = serializers.IntegerField()
# hote_used1 = HotelServicesUsedByGuestsSerializer(many=True,read_only=False)
    class Meta:
        model = HotelServices
        fields = '__all__'

class bookingsSerializer(serializers.ModelSerializer):
    class Meta:
        model = bookings
        fields = '__all__'


    def validate_booking_payment_type(self, value):
        if value == "credit_card":
            raise ValidationError("No creadit card Please")


    def validate(self, data):
        if data["duration_of_stay"] == "20 days":
            raise ValidationError({"duration_of_stay": "pleas select less than 20 days"})


    def create(self, data):
        return bookings.objects.create(**data)
# room_booked_user1 = RoomsBookedSerializer(many=True,read_only=False)
#  hotel_used = HotelServicesUsedByGuestsSerializer(many=True,read_only=False)
# to get rid of folowing codes use class serializer with Model serializer

    def update(self, instance, data):
        instance.booking_id = data.get('booking_id', instance.booking_id)
        instance.duration_of_stay = data.get('duration_of_stay', instance.duration_of_stay)
        instance.check_in_date = data.get('check_in_date', instance.check_in_date)
        instance.check_out_date = data.get('check_out_date', instance.check_out_date)
        instance.booking_payment_type = data.get('booking_payment_type', instance.booking_payment_type)
        instance.total_rooms_booked = data.get('total_rooms_booked', instance.total_rooms_booked)
        instance.total_amount = data.get('total_amount', instance.total_amount)
        instance.booking_date = data.get('booking_date', instance.booking_date)
        instance.hotel_hotel = data.get('hotel_hotel', instance.hotel_hotel)
        instance.guests_guest = data.get('guests_guest', instance.guests_guest)

        instance.save()
        return instance

class GuestsSerializer(serializers.ModelSerializer):
# booking_user1 = bookingsSerializer(many=True,read_only=False)
    class Meta:
        model = Guests
        fields = '__all__'

class HotelSerializer(serializers.ModelSerializer):
# booking_user = bookingsSerializer(many=True,read_only=False)
# guest_user = GuestsSerializer(many=True,read_only=False)
#   hotel_service_user = HotelServicesSerializer(many=True,read_only=False)
#   room_user = RoomsSerializer(many=True, read_only=False)
    class Meta:
        model = Hotel
        fields = '__all__'


class HotelAddressesSerializer(serializers.ModelSerializer):
# hotel_user = HotelSerializer(many=True,read_only=False)
    class Meta:
        model = HotelAddresses
        fields = '__all__'

class LocationSerializer(serializers.ModelSerializer):
# address_user = HotelAddressesSerializer(many=True,read_only=False)
    class Meta:
        model = Location
        fields = '__all__'


# class guest_journey_details(serializers.Serializer):
#     class Meta:
#         model = [Location, Hotel,Guests,bookings,RoomType,Rooms,RoomsBooked,HotelServices,HotelServicesUsedByGuests,RoomRateDiscount]
#         fields = ['guest_id', 'guest_first_name', 'guest_last_name', 'city_id','hotel_name']
