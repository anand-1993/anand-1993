from django.db import models



class Location(models.Model):
    city_id = models.AutoField(primary_key=True)
    city_name = models.CharField(max_length=45, blank=True, null=True)

    class Meta:
        managed = True
        db_table = 'Location'

    def __str__(self):
        return self.city_name


class HotelAddresses(models.Model):
    address_id = models.AutoField(primary_key=True)
    address_line1 = models.CharField(max_length=100, blank=True, null=True)
    city_id_fk = models.ForeignKey('Location', models.DO_NOTHING, db_column='city_id_fk', blank=True, null=True)
    state = models.CharField(max_length=45, blank=True, null=True)
    country = models.CharField(max_length=45, blank=True, null=True)
    zipcode = models.CharField(max_length=6, blank=True, null=True)

    class Meta:
        managed = True
        db_table = 'HotelAddresses'

    def __str__(self):
        return self.address_line1


class Hotel(models.Model):
    hotel_id = models.AutoField(primary_key=True)
    hotel_name = models.CharField(max_length=100, blank=True, null=True)
    hotel_contact_number = models.CharField(max_length=25, blank=True, null=True)
    hotel_description = models.CharField(max_length=255, blank=True, null=True)
    hotel_floor_count = models.IntegerField(blank=True, null=True)
    hotel_room_capacity = models.IntegerField(blank=True, null=True)
   # addresses_address = models.ForeignKey('HotelAddresses',related_name="hotel_user",null=True,on_delete=models.CASCADE)
    addresses_address = models.ForeignKey('HotelAddresses',  null=True,on_delete=models.CASCADE)
    star_ratings_star_rating = models.IntegerField()
    check_in_time = models.CharField(max_length=15, blank=True, null=True)
    check_out_time = models.CharField(max_length=15, blank=True, null=True)

    class Meta:
        managed = True
        db_table = 'Hotel'

    def __str__(self):
        return self.hotel_name


class Guests(models.Model):
    guest_id = models.AutoField(primary_key=True)
    guest_first_name = models.CharField(max_length=45, blank=True, null=True)
    guest_last_name = models.CharField(max_length=45, blank=True, null=True)
    guest_contact_number = models.CharField(max_length=12, blank=True, null=True)
    guest_email_address = models.CharField(max_length=45, blank=True, null=True)
    guest_credit_card = models.CharField(max_length=45, blank=True, null=True)
    guest_id_proof = models.CharField(max_length=45, blank=True, null=True)
#    guest_hotel = models.ForeignKey('Hotel', related_name="guest_user", null=True,on_delete=models.CASCADE)
    guest_hotel = models.ForeignKey('Hotel',  null=True, on_delete=models.CASCADE)

    class Meta:
        managed = True
        db_table = 'Guest'

    def __str__(self):
        return self.guest_last_name


class bookings(models.Model):
    booking_id = models.AutoField(primary_key=True,blank=True)
    duration_of_stay = models.CharField(max_length=10, blank=True, null=True)
    check_in_date = models.DateTimeField(blank=True, null=True)
    check_out_date = models.DateTimeField(blank=True, null=True)
    booking_payment_type = models.CharField(max_length=45, blank=True, null=True)
    total_rooms_booked = models.IntegerField(blank=True, null=True)
    #hotel_hotel = models.ForeignKey('Hotel', related_name="booking_user", null=True,on_delete=models.CASCADE)
    hotel_hotel = models.ForeignKey('Hotel',null=True, on_delete=models.CASCADE)
    #guests_guest = models.ForeignKey('Guests',  related_name="booking_user1",on_delete=models.CASCADE, null=True)
    guests_guest = models.ForeignKey('Guests', on_delete=models.CASCADE, null=True)
    total_amount = models.DecimalField(max_digits=10, decimal_places=2, blank=True, null=True)
    booking_date = models.DateTimeField()

    class Meta:
        managed = True
        db_table = 'bookings'

    def __str__(self):
        return str(self.booking_id)



class RoomType(models.Model):
    room_type_id = models.AutoField(primary_key=True)
    room_type_name = models.CharField(max_length=45, blank=True, null=True)
    room_cost = models.DecimalField(max_digits=10, decimal_places=2, blank=True, null=True)
    room_type_description = models.CharField(max_length=255, blank=True, null=True)
    smoke_friendly = models.IntegerField(blank=True, null=True)
    pet_friendly = models.IntegerField(blank=True, null=True)

    class Meta:
        managed = True
        db_table = 'RoomType'

    def __str__(self):
        return self.room_type_name


class HotelServices(models.Model):
    service_id = models.AutoField(primary_key=True)
    service_name = models.CharField(max_length=45, blank=True, null=True)
    service_description = models.CharField(max_length=100, blank=True, null=True)
    service_cost = models.DecimalField(max_digits=10, decimal_places=2, blank=True, null=True)
    #hotel_hotel = models.ForeignKey('Hotel', related_name="hotel_service_user", null=True,on_delete=models.CASCADE)
    hotel_hotel = models.ForeignKey('Hotel',  null=True, on_delete=models.CASCADE)

    class Meta:
        managed = True
        db_table = 'HotelServices'

    def __str__(self):
        return self.service_name


class HotelServicesUsedByGuests(models.Model):
    service_used_id = models.AutoField(primary_key=True)
    hotel_services_service = models.ForeignKey(HotelServices, on_delete=models.CASCADE, null=True)
   # bookings_booking = models.ForeignKey('bookings',  related_name="hotel_used",on_delete=models.CASCADE, null=True)
    bookings_booking = models.ForeignKey('bookings', on_delete=models.CASCADE, null=True)

    class Meta:
        managed = True
        db_table = 'HotelServicesUsedByGuests'

    def __str__(self):
        return self.service_used_id


class RoomRateDiscount(models.Model):
    discount_id = models.AutoField(primary_key=True)
    discount_rate = models.DecimalField(max_digits=10, decimal_places=2, blank=True, null=True)
    start_month = models.IntegerField(blank=True, null=True)
    end_month = models.IntegerField(blank=True, null=True)
    #room_type_room_type = models.ForeignKey('RoomType',  related_name="rate_discount_user", null=True,on_delete=models.CASCADE)
    room_type_room_type = models.ForeignKey('RoomType',  null=True, on_delete=models.CASCADE)

    class Meta:
        managed = True
        db_table = 'RoomRateDiscount'

    def __str__(self):
        return self.discount_id


class Rooms(models.Model):
    room_id = models.AutoField(primary_key=True)
    room_number = models.IntegerField(blank=True, null=True)
    rooms_type_rooms_type = models.ForeignKey(RoomType, models.DO_NOTHING, null=True)
   # hotel_hotel = models.ForeignKey('Hotel',  related_name="room_user",null=True,on_delete=models.CASCADE)
    hotel_hotel = models.ForeignKey('Hotel',null=True, on_delete=models.CASCADE)

    class Meta:
        managed = True
        db_table = 'Rooms'

    def __str__(self):
        return str(self.room_id)


class RoomsBooked(models.Model):
    rooms_booked_id = models.AutoField(primary_key=True)
 #   bookings_booking = models.ForeignKey('bookings', related_name="room_booked_user1",on_delete=models.CASCADE, null=True)
    bookings_booking = models.ForeignKey('bookings',  on_delete=models.CASCADE,null=True)
    #rooms_room = models.ForeignKey('Rooms', related_name="room_booked_user",on_delete=models.CASCADE, null=True)
    rooms_room = models.ForeignKey('Rooms',on_delete=models.CASCADE, null=True)

    class Meta:
        managed = True
        db_table = 'RoomsBooked'

    def __str__(self):
        return self.rooms_booked_id




from django.db import models

# Create your models here.
