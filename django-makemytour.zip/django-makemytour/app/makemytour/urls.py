"""makemytour URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path('', include('hotels.urls')),
    path('location_update/', include('hotels.urls')),
    path('hotel_update/', include('hotels.urls')),
    path('guest_update/', include('hotels.urls')),
    path('admin/', admin.site.urls),
    path('booking_update/', include('hotels.urls')),
    path('hotel_update/', include('hotels.urls')),
    path('hotel_service_update/', include('hotels.urls')),
    path('room_type_update/', include('hotels.urls')),
    path('room_update/', include('hotels.urls')),
    path('room_rate_discount_update/', include('hotels.urls')),
    path('hotel_service_use_update/', include('hotels.urls')),
    path('room_booked_update/', include('hotels.urls')),
    path('bookingsystem/', include('train_api.urls')),
    path('mahabaleshwar/', include('mahabaleshwar_monuments.urls')),
    path('mahabaleshwar/', include('mahabaleshwar_spiritual.urls')),
    path('mahabaleshwar/', include('mahabaleshwar_watersports.urls')),
    path('mahabaleshwar/', include('mahabaleshwar_wildlife_nature.urls')),
    path('pune/', include('pune_monuments.urls')),
    path('pune/', include('pune_spiritual.urls')),
    path('pune/', include('pune_watersports.urls')),
    path('pune/', include('pune_wildlife_nature.urls')),
    path('mumbai/', include('mumbai_monuments.urls')),
    path('mumbai/', include('mumbai_spiritual.urls')),
    path('mumbai/', include('mumbai_watersports.urls')),
    path('mumbai/', include('mumbai_wildlife_nature.urls')),

]
