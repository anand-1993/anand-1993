from django.contrib import admin
from .models import wildlife_nature
admin.site.register(wildlife_nature)

