from django.shortcuts import render
from rest_framework.response import Response
from rest_framework import status
from .models import wildlife_nature
from .serializers import wildlife_natureSerializer
from rest_framework.renderers import JSONRenderer
from django.http import HttpResponse,JsonResponse
from rest_framework.response import Response
from rest_framework import status
from .models import wildlife_nature
from .serializers import wildlife_natureSerializer
from rest_framework.renderers import JSONRenderer
from django.http import HttpResponse,JsonResponse
from rest_framework.decorators import api_view ,APIView

# @api_view(['GET'])
# def wildlife_nature_places(request):
#     place= wildlife_nature.objects.all()
#     serializer = wildlife_natureSerializer(place,many=True)
#     return JsonResponse(serializer.data,safe=False)

class wildlife_nature_places(APIView):
    def get(self,request):
        info = wildlife_nature.objects.all()

        serializer = wildlife_natureSerializer(info, many=True)
        return Response(serializer.data)

    def post(self, request):
        serializer = wildlife_natureSerializer(data=request.data)

        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)

        else:
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class wildlife_nature_update(APIView):

    def get(self, request, pk):
        try:
            wildlife_nature_id = wildlife_nature.objects.get(pk=pk)
        except:
            return Response({"Error": "wildlife_nature is not exist"}, status=status.HTTP_404_NOT_FOUND)
        serializer = wildlife_natureSerializer(wildlife_nature_id)
        return Response(serializer.data)


    def put(self,request, pk):
        wildlife_nature_id = wildlife_nature.objects.get(pk=pk)
        serializer = wildlife_natureSerializer(wildlife_nature_id, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


    def delete(self,request,pk):
        wildlife_nature_id = wildlife_nature.objects.get(pk=pk)
        wildlife_nature_id.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)



