from rest_framework import serializers
from .models import *


from .models import *

class wildlife_natureSerializer(serializers.ModelSerializer):
    # places = serializers.CharField(max_length=100)
    # Idwildlife_nature = serializers.IntegerField()
    class Meta:
        model = wildlife_nature
        fields = '__all__'
