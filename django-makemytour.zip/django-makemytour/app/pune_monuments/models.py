from django.db import models

class monuments(models.Model):
    places = models.CharField(max_length=100)

    class Meta:
        managed = True
        db_table = 'pune_monuments_monuments'


    def __str__(self):
        return self.places



