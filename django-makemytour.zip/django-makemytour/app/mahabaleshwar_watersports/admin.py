from django.contrib import admin
from .models import watersports

admin.site.register(watersports)

