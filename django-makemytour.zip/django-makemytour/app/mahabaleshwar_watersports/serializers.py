from rest_framework import serializers
from .models import *


from .models import *


class watersportsSerializer(serializers.ModelSerializer):
    # places = serializers.CharField(max_length=100)
    # Idwatersports = serializers.IntegerField()
    class Meta:
        model = watersports
        fields = '__all__'
