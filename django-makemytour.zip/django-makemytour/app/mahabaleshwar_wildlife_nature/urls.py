from django.test import TestCase

# Create your tests here.
from django.urls import path
from .views import *
# from django.contrib import admin


urlpatterns = [
    # path('wildlife_nature/',views.wildlife_nature_places),
    path('wildlife_nature/',wildlife_nature_places.as_view()),
    path('wildlife_nature_update/<int:pk>/',wildlife_nature_update.as_view())
]