from django.db import models

class wildlife_nature(models.Model):
    places = models.CharField(max_length=100)

    class Meta:
        managed = True
        db_table = 'mahabaleshwar_wildlife_nature_wildlife_nature'

    def __str__(self):
        return self.places

