from django.db import models

class spiritual(models.Model):
    places = models.CharField(max_length=100)

    class Meta:
        managed = True
        db_table = 'mumbai_spiritual_spiritual'

    def __str__(self):
        return self.places


