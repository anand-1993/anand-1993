-- create table `python` . `customer`(`id` int not null auto_increment , `name` varchar(255) null , primary key(`id`));
 -- select * from python.student;
 -- select * from student where name = 'Anuraj';
 -- insert into `python` . `student` (name) values ('akash');
 -- create view  `my_view` as select id from customer;
 -- select name as name1, id as id1 from python.student;

-- @ procedure , invoke using call, it does not returns values
 -- CREATE PROCEDURE `new_procedure` () 
 -- BEGIN 
 -- select * from student; 
 -- END 
 -- call new_procedure();


-- @ function , invoke using select, it returns values
 -- CREATE FUNCTION `new_function` ()
 -- RETURNS INTEGER 
 -- BEGIN
 -- insert into student (name) values ('test');
 -- RETURN 1;
 -- END
-- select new_function()


-- @ trigeer 
 -- Trigger: A trigger is a stored procedure in database 
 -- which automatically invokes whenever a special event in the database occurs. 
 -- For example, a trigger can be invoked when a row is inserted into a specified 
 -- table or when certain table columns are being updated.
 -- [before | after] for each insert , update and delete. 

 -- create trigger stud_marks -- triger name
 -- before INSERT 
 -- on 
 -- Student 
 -- for each row 
 -- set Student.total = Student.subj1 + Student.subj2 + Student.subj3, Student.per = Student.total * 60 / 100

-- DDL (data defination language) 
 -- creat , drop, truncate, alter, rename
 -- alter table student1 `Age` int;
 -- drop table student1;
 -- alter table student1 add `Address` varchar(255) null after `Age`;
 -- alter table student1 rename to student_data;
 -- truncate python.student
 -- create database if not exists movies character set utf8mb4 collate latin1_general_ci;

-- @ comment
 -- single line comment
/* this is database
sql queery language */  -- multiline comment
 

-- DQL (data query language)

 /* AND ,OR ,BOOLEAN, LIKE(pattern matching), IN, NOT IN, ANY, EXISTS
 IS NULL, IS NOT Null, BETWEEN, <>=!=, distinct, subquery/nested query

/*  DQL statements are used for performing queries on the data within schema objects. 
The purpose of DQL commands is to get the schema relation based on the query passed to it. */
 -- select > it is used to reteive data from table.
 -- SELECT * FROM python.student where name = 'Anand';
 -- select * from python.student where Address like 'Nagpur';
 -- select * from python.student where Address like '%na%'; works like substring return table where all adress contain string 'na'.
 -- 1)select * from python.student where name not in ('Anand', 'anand'); 
 -- 2)select * from python.student where name != 'Anand' or name  != 'anand'; both are same
 -- select name from student where Age = any (select Age from student where Age > 20); >> any subquery
 -- select * from student where Age = any (select Age from student where Age > 20); >> all data
 -- select * from student where  exists (select Address from student where Address = 'Nagpur'); exist subquery
 -- select * from student where Address is null; return table where address is not given and empty.alter
 -- select * from student where Age between 15 and 28;
 -- <> = !=
 -- select * from student where Age < 20;
-- select distinct (Address) , Age, name from python.student; unique record
 -- select * from python.student where name in (select name from python.student where name = 'Anand' or name = 'anand');
 -- select * from (select name from python.student where name = 'Anand' or name = 'anand') as test1; test1 will ba a table 

-- @ Aggregate function
 -- select count(*) from python.student;  return number of entries (rows) from table
 -- select count(*) from python.student where name = 'Anand' or name = 'Akash'; specific records
 -- select sum(Age) from python.student where name = 'Anand' or name = 'Akash';
 -- select avg(Age) from python.student where name = 'Anand' or name = 'Akash';
 -- select min(Age) from python.student where name = 'Anand' or name = 'Akash';
 -- select max(Age) from python.student where name = 'Anand' or name = 'Akash'; 
 -- select * from student limit 5; first five entries
 -- select * from student order by Age desc limit 2; 
 --  select * from student order by Age asc limit 7;
 -- select * from student limit 2; show upto two rows in table in sequence.
 -- select * from student limit 5,2; show uocommingtwo rows after row no. 5
 -- select * from student limit 5 offset 2; shows 5 rows starting after row no 2
-- @@@having
 -- select name, age, sum(age) from student group by name, age having sum(age) > 10;

 


-- DMl (data manipulation language)
 /* INSERT : It is used to insert data into a table.
 UPDATE: It is used to update existing data within a table.
 DELETE : It is used to delete records from a database table.
 LOCK: Table control concurrency.
 CALL: Call a PL/SQL or JAVA subprogram.
 EXPLAIN PLAN: It describes the access path to data.*/

 -- update  `python` . `student` set Address = 'Nagpur' where (`id`) = 1;
 -- update  `python` . `student` set Address = 'Nagpur' where (`id`) = 2;
 -- delete from student where name = 'anand';


-- DCL (data control language)
 -- Grant > this command gives ussers access priviliges to the database.
 -- Revoke> this command withdraw the priviliges 



-- @ Database Table Relation
 /* databse relation is about how the data in one table is related the data in another table
 in RDBMS the term 'Ralational' refers to the tables with relations. 
 relation between two tables are creatd using KEYS, key in one table is related tp the key in another table */
 -- REALTION
  -- One to one (1:1)
  -- One to many (1: M)
  -- Many to many( M : M)
 
 -- @ Normalisation 
  -- it is process of efficiently organise the data in database, it eliminate the reduntant data.
  -- 1NF, 2 NF, 3NF, 4NF, BCNf
 

-- @ Join
   -- Inner join (Intersection) 
   -- Left Join (Left outer Join)
   -- Right join (Right outer Join)
   -- self Join / cross join/ cartesian join
   -- innner join
	  -- select * from customer inner join student on customer.studentid = student.id;
      -- select * from customer inner join student on customer.studentid = student.id where student.id = 8;
			-- shows data from reffeenced table student
   -- Left Join
		-- select * from student left join customer on customer.studentid = student.id;
   -- Right Join
		-- select * from customer right join student on customer.studentid = student.id;
   -- Cross Join
		-- select * from customer cross join student;
        
-- unique kye vs primary key
    -- we can not assign null to primary key. we can assign null to unique key only one
   