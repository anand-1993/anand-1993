from flask import Flask, jsonify, request
from flask_sqlalchemy import SQLAlchemy
import json
app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://root:anand123@localhost/python'
db = SQLAlchemy(app)
# 'mysql+pymysql://username:password@localhost/db_name'

class Hospital(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80),  nullable=True)
    email = db.Column(db.String(120),  nullable=True)
    address = db.Column(db.String(120), nullable=True)
    #mobile_no = db.Column(db.Integer, nullable = True)



    def __repr__(self):
        return '<Traveling %r>' % self.username

db.create_all()
@app.route("/create_user", methods = ['GET','POST'])
def create_student():
    print(request.json)
    hptl = Hospital()
    hptl.username = request.json.get('username')
    #hptl.username = request.args.get('username', '')
    hptl.email = request.json.get('email')
    #hptl.email = request.args.get('email', '')
    hptl.address = request.json.get('address')
   # hptl.mobile_no = request.json.get('mobile_no')
    #hptl.address = request.args.get('address', '')
    dictionry = {"Username" : hptl.username, "email" : hptl.email, "address": hptl.address}
    db.session.add(hptl)
    db.session.commit()
  #  print("Welcome")
    return jsonify({"success" : dictionry})
#admin = Traveling(username='admin', email='admin@example.com', address='Delhi')
#guest = Traveling(username='guest', email='guest@example.com', address='Nagpur')
#db.session.add(admin)
#db.session.add(guest)
#db.session.commit()
@app.route("/getUser", methods =['GET'])
def getUser():
    data = request.args.get('id', '')
    getdata = Hospital.query.filter_by(id = data).first()
    dictionary  = {"username" : getdata.username, "email" : getdata.email, "address" : getdata.address}
    return jsonify({"data" : dictionary}) # works in both browser and json


@app.route("/delete_user", methods = ['GET','DELETE'])
def delete_user():
    data =request.args.get('id', '')
    #data1 = request.args.get('id', '')
    #getdata = Hospital.query.filter_by(id=data1).first()
    data1 = Hospital.query.filter_by(id = request.json.get('id')).first()
   # data1 = Hospital.query.filter_by(id=data).first()
    db.session.delete(data1)
    db.session.commit()
    return jsonify({"success": "data associated with ID is deleted successfuly"})

@app.route("/update_record", methods = ['GET','PUT'])
def updat_data():
    #data1 =request.args.get('id', '')
    #data = Hospital.query.filter_by(id = data1).first()
    data = Hospital.query.filter_by(id=request.json.get('id')).first()
    data.username = request.json.get("username")
    #data.username = request.args.get("username")
    #data.email = request.args.get("email")
    #data.address = request.args.get("address")
  #  data.email = request.json.get("email")
   # data.address = request.json.get("address")
    db.session.add(data)
    db.session.commit()
    return jsonify({"success" : "Records is update by given id"})


@app.route("/update_single", methods= ['GET','PATCH'])
def alter():
    flag = False
    data = Hospital.query.filter_by(id= request.json.get('id')).first()
    #data1 = request.args.get('id', '')
    #data = Hospital.query.filter_by(id = data1).first()
    if data is None:
        flag = True
        data = Hospital()
    #data.username = request.json.get('username')
    #data.email = request.json.get('email')
    #data.address = request.json.get('address')
    data.username = request.args.get('username')
    data.email = request.args.get('email')
    data.address = request.args.get('address')
    db.session.add(data)
    db.session.commit()
    if flag:
        return jsonify({"success": "new record  is added"})
    else:
        return jsonify({"success": "new record entity is added"})

if __name__ == '__main__':
    app.run()


"""@app.route("/sqlq", methods =['GET'])
def query():
    result = db.session.execute('SELECT * FROM hospital WHERE id =:val', {'val' : 3}) # paramiterized query to stop sql injection
    for results in result:
        print(results)
    return jsonify({"success": "yes data is got"})"""


