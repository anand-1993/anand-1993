import json, requests

def lambda_handler(event, context):
    # TODO implement
    print(event)
    x = requests.get('http://jsonplaceholder.typicode.com/todos/1')
    print(x)
    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }
