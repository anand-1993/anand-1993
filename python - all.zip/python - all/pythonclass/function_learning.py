# Python Function
#A function is a block of code which only runs when it is called.
#You can pass data, known as parameters, into a function.
#A function can return data as a result.

# Creating a Function
#In Python a function is defined usung the def keyword:
# Example
def my_function():
   print("Hello from a function")


my_function() # calling Function

# Arguments #
# Information can be passed into functions as arguments.
# Arguments are specified after the function name, inside the parentheses.
# You can add as many arguments as you want, just separate them with a comma.
# The following example has a function with one argument (fname).
# When the function is called, we pass along a first name,
# which is used inside the function to print the full name:
def my_function(fname):
    print(fname + " Refsnes")

my_function("Email")
my_function("Linus")
my_function("Thanos")

# Parameters or Arguments?
# The terms parameter and argument can be used for the same thing:
# information that are passed into a function.
# From a function's perspective:
# A parameter is the variable listed inside the parentheses in the function definition.
# An argument is the value that is sent to the function when it is called.


#Number of Arguments
#By default, a function must be called with the correct number of arguments.
# Meaning that if your function expects 2 arguments, you have to call the function with 2 arguments,
# not more, and not less.
def arg(fname, lname):
    print(fname, " " + lname)
arg("Anand", "Somkuwar")

# Arbitrary Arguments, *args
#If you do not know how many arguments that will be passed into your function,
# add a * before the parameter name in the function definition.
# This way the function will receive a tuple of arguments, and can access the items accordingly:
def mulfun(ar1, *ar2):
     print(ar1, ar2)
     print(ar2[3])

mulfun(12, 45,546,546,5465,"anand")

# Arbitrary Arguments are often shortened to *args in Python documentations.

#Keyword Arguments
#You can also send arguments with the key = value syntax.
#This way the order of the arguments does not matter.

def keyFun(Task1, Task2, Task3):
    print("This is your Tasks= ", Task2,Task1, Task3 )
keyFun(Task3= "String", Task1= "Python", Task2="AWS")

# The phrase Keyword Arguments are often shortened to kwargs in Python documentations.
def MulKeywd(**a):
    print("My First Name is ", a["Fname"], "Last name is ", a["Lanme"])
MulKeywd(Fname = "Anand", Lanme = "Somkuwar")
# Arbitrary Kword Arguments are often shortened to **kwargs in Python documentations.

#Default Parameter Value
#The following example shows how to use a default parameter value.
#If we call the function without argument, it uses the default value:
def DefaultFun(country = "India"):
    print("I am from ", country)
DefaultFun("America")
DefaultFun("China")
DefaultFun()
DefaultFun("Canada")

# Nested Function
def outFun(y):
    print(" Value of Y is in Outer Function ", y)

    def innerFirst(x):
        print("Value of X is in Inner First Function ", x)
        print("we can outer function in nested function")
        def InnerThird(z):
            print("Value of Z is in Inner Third Function ", z)
        InnerThird(20)
    innerFirst(30)
outFun(10)

# The pass Statement
# function definitions cannot be empty,
# but if you for some reason have a function definition with no content, put in the pass statement to avoid getting an error.
def nopaass():
    pass
# Recursion
# Python also accepts function recursion, which means a defined function can call itself.
# Recursion is a common mathematical and programming concept. It means that a function calls itself.
# This has the benefit of meaning that you can loop through data to reach a result.
# The developer should be very careful with recursion as it can be quite easy to slip into writing a function which never terminates,
# or one that uses excess amounts of memory or processor power. However, when written correctly recursion can be a very efficient
# and mathematically-elegant approach to programming.
# In this example, tri_recursion() is a function that we have defined to call itself ("recurse"). We use the k variable as the data,
# which decrements (-1) every time we recurse. The recursion ends when the condition is not greater than 0 (i.e. when it is 0).
# To a new developer it can take some time to work out how exactly this works, best way to find out is by testing and modifying it
def myrec(k):
    for i in reversed(k):
        print(i)










print(" data in List")
g=[2,4,2,8,10]
myrec(g)
myrec(g)