# Casting in python is therefore done using constructor functions:
# int() - constructs an integer number from an integer literal, a float literal (by removing all decimals),or a string literal (providing the string represents a whole number)
# float() - constructs a float number from an integer literal, a float literal or a string literal (providing the string represents a float or an integer)
# str() - constructs a string from a wide variety of data types, including strings, integer literals and float literals
# int
x = int(4)   # x will be 4
y = int(93.99) # y will be 93
z = int("45") # z will be 45
print(x, y, z)

# Float
x = float(4)   # x will be 4.0
y = float(93.99) # y will be 93.99
z = float("45") # z will be 45.00
w = float("10")
print(x, y, z, w)

# String
x = str(4)   # x will be 4
y = str(93.99) # y will be 93
z = str("45") # z will be 45
w = str("strin1")
print(x, y, z, w)