# Strings in python are surrounded by either single quotation marks, or double quotation marks.
# You can display a string literal with the print() function:
print('anand')
print("anand")
# Assigning a string to a variable is done with the variable name followed by an equal sign and the string:
StrVar = "Hello Word"
print(StrVar)

# You can assign a multiline string to a variable by using three quotes:

a = """Lorem ipsum dolor sit amet,
consectetur adipiscing elit,
sed do eiusmod tempor incididunt
ut labore et dolore magna aliqua."""
print(a)

# Or three single quotes:
a = '''Lorem ipsum dolor sit amet,
consectetur adipiscing elit,
sed do eiusmod tempor incididunt
ut labore et dolore magna aliqua.'''
print(a)
# Note: in the result, the line breaks are inserted at the same position as in the code.
print(StrVar[1])
# Loop through the letters in the word "banana":
for x in "Anand":
    print(x)
# To get the length of a string, use the len() function. show output true
print(len(StrVar))
Langstr = "This, is, Python, Language"
print("is" in Langstr)
# Use it in an if statement:
if "is" in Langstr:
    print("yes it is available")
# To check if a certain phrase or character is NOT present in a string, we can use the keyword not in. shows True
print("son" not in Langstr)
# To concatenate, or combine, two strings you can use the + operator.


# Get the characters from position 2 to position 5 (not included):
print(Langstr[2:9]) #[9] index wont be included
# Get the characters from the start to position 5 (not included):
print(Langstr[:7])
# By leaving out the end index, the range will go to the end:
print(Langstr[5:])
# Use negative indexes to start the slice from the end of the string:
print(Langstr[-4:-1])
# The upper() method returns the string in upper case/ The lower() method returns the string in lower case:
print(Langstr.upper())
print(Langstr.lower())
# Whitespace is the space before and/or after the actual text, and very often you want to remove this space.
# The strip() method removes any whitespace from the beginning or the end:
print(a.strip())
print(Langstr.replace("This", "THIS"))
# The split() method returns a list where the text between the specified separator becomes the list items.
print(Langstr.split("--"))
# To concatenate, or combine, two strings you can use the + operator.
print(StrVar + Langstr)
# To add a space between them, add a " ":
print(StrVar+ " " +Langstr)
# The format() method takes the passed arguments, formats them, and places them in the string where the placeholders {} are:
# Use the format() method to insert numbers into strings:
age = 30
txt = "I Am Anand, and I am {} years old "
print(txt.format(age))
# The format() method takes unlimited number of arguments, and are placed into the respective placeholders:
quantity = 3
itemno = 567
price = 49.95
myorder = "I want {} pieces of item {} for {} dollars."
print(myorder.format(quantity, itemno, price))
# You can use index numbers {0} to be sure the arguments are placed in the correct placeholders:
quantity = 3
itemno = 567
price = 49.95
myorder = "I want to pay {2} dollars for {0} pieces of item {1}."
print(myorder.format(quantity, itemno, price))
# To insert characters that are illegal in a string, use an escape character.
# An escape character is a backslash \ followed by the character you want to insert.

txt = "We are the so-called \"Vikings\" from the north."
print(txt)
print(txt.title())
name = "PANKAJ" #1
print(name.center(100))

# Escape Characters
# \'	Single Quote
# \\	Backslash
# \n	New Line
# \r	Carriage Return
# \t	Tab
# \b	Backspace
# \f	Form Feed
# \ooo	Octal value
# \xhh	Hex value
""" 
Method	Description
capitalize()	     >>Converts the first character to upper case
casefold()	         >>Converts string into lower case
center()	         >>Returns a centered string
count()	             >>Returns the number of times a specified value occurs in a string
encode()	         >>Returns an encoded version of the string
endswith()	         >>Returns true if the string ends with the specified value
expandtabs()	     >>Sets the tab size of the string
find()	             >>Searches the string for a specified value and returns the position of where it was found
format()	         >>Formats specified values in a string
format_map()	     >>Formats specified values in a string
index()	             >>Searches the string for a specified value and returns the position of where it was found
isalnum()	         >>Returns True if all characters in the string are alphanumeric
isalpha()	         >>Returns True if all characters in the string are in the alphabet
isdecimal()	         >>Returns True if all characters in the string are decimals
isdigit()	         >>Returns True if all characters in the string are digits
isidentifier()	     >>Returns True if the string is an identifier
islower()	         >>Returns True if all characters in the string are lower case
isnumeric()	         >>Returns True if all characters in the string are numeric
isprintable()	     >>Returns True if all characters in the string are printable
isspace()	         >>Returns True if all characters in the string are whitespaces
istitle()	         >>Returns True if the string follows the rules of a title
isupper()	         >>Returns True if all characters in the string are upper case
join()	             >>Joins the elements of an iterable to the end of the string
ljust()	             >>Returns a left justified version of the string
lower()	             >>Converts a string into lower case
lstrip()	         >>Returns a left trim version of the string
maketrans()	         >>Returns a translation table to be used in translations
partition()	         >>Returns a tuple where the string is parted into three parts
replace()	         >>Returns a string where a specified value is replaced with a specified value
rfind()	             >>Searches the string for a specified value and returns the last position of where it was found
rindex()	         >>Searches the string for a specified value and returns the last position of where it was found
rjust()	             >>Returns a right justified version of the string
rpartition()	     >>Returns a tuple where the string is parted into three parts
rsplit()	         >>Splits the string at the specified separator, and returns a list
rstrip()	         >>Returns a right trim version of the string
split()	             >>Splits the string at the specified separator, and returns a list
splitlines()	     >>Splits the string at line breaks and returns a list
startswith()	     >>Returns true if the string starts with the specified value
strip()	             >>Returns a trimmed version of the string
swapcase()	         >>Swaps cases, lower case becomes upper case and vice versa
title()	             >>Converts the first character of each word to upper case
translate()	         >>Returns a translated string
upper()	             >>Converts a string into upper case
zfill()	             >>Fills the string with a specified number of 0 values at the beginning
"""