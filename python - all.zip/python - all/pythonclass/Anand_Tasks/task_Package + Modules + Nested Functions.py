# 1) Create package with Cricket anad create subpackage players and some methods t
# o and call that method in the top packages.
def players(list1):
    print(list1)


print("enter array")
x = input()

players(x)


# from Player.Player import players
# import Player.Player as p

# 2 ) Write two modules with python1 and python2 and write some method in that modules ,
# use thsoe module method in seperate file
# PYTHON1
def sorting(name):
    name.sort()
    new = ""
    for i in name:
        new = new + i
    return new


x = input("enter string    ").split()
y = sorting(x)
print(y)


# PYTHON2
def rev(name):
    count = 0
    temp = ""
    new = ""
    for i in name:
        for x in name:
            if i == x:
                count += 1
                continue
        if count > 1:
            new += i
        count = 0
    for i in name:
        if i not in new:
            temp += i
    return temp
    print(temp)


print("Enter String")
x = input()
print("reverse if it is ", rev(x))
# MAIN FILE
# import python1
# import python2
# from python1 import sorting as select
# from python2 import rev as reverse

# 3) do addition of two number using nested function with with local global and non local keywords.
x = 45


def summ():
    c = 54

    def addd():
        global x
        nonlocal c
        print(x + c)

    addd()


summ()

# 4) Write program to count sum of array and add exception block to it. raise some exception from that method.

# 5)  Use datetime module and print today's date.
import datetime

print(datetime.date.today())


# 6) Write function which should accept the array of list and print those array list.
def arraydata(list1):
    print(list1)


print("Enter data in list")
x = input().split(" ")
arraydata(x)


# 9) Write function to accept the named arguments and print those functions.
# def nam(name):
# print(name)
# print("Enter Name")
# x=input()
# nam(x)

# 7) Write program factorial program use Recursion
def facto(n):
    if n == 1:
        return n
    else:
        return n * facto(n - 1)


print("Enter No to find its Factorial")
x = int(input())
print(facto(int(x)))


# 8) Write function which should accept the array of list and print those array list.
def alist():
    print("enter array data")
    x = input().split()
    print(x)


alist()


#   /* New series */  #

# 1) Write python function which takes a variable number of arguments.
def varnum(v):
    print(v)


x = 100
varnum(x)

# 2) WAP (Write a program) which takes a sequence of numbers and check if all numbers are unique.
print("Enter Numbers")
x = input().split()
l = set(x)
flag = False
for i in x:
    if i in l:
        flag = True
        continue
    else:
        flag = False
if flag and len(x) == len(l):
    print("All are unique")
else:
    print("Not Unique")


# 3) Write a program to check and return the pairs of a given array A whose sum value is equal to a target value N.

def checksum(L, n):
    list1 = []
    for i in L:
        list1.append(int(i))
    return sum(list1) == int(n)


n = input("Enter value of N   ")
L = input("Enter values  ").split(" ")
print(checksum(L, n))

# 4)  Write a Program to add two integers >0 without using the plus operator.
x = input().split()
for i in range(len(x)):
    x.insert(i, int(x[i]))
    x.remove(x[i + 1])
print(x)

# 5) Write a Program to convert date from yyyy-mm-dd format to dd-mm-yyyy format.
import datetime

datetime.datetime.strptime()
# 6) Write a Program to combine two different dictionaries. While combining,
# if you find the same keys, you can add the values of these same keys. Output the new dictionary
dict1 = {'nmae': "Anand", 'age': 28}
dict2 = {'Edu': "BE", 'Stream': "CE", 'age': 27}
dict1.update(dict2)
print(dict1)

# 7) Print followng pattern
#
# A
# B C
# D E F
# G H I J
# K L M N O
# P Q R S T U
A = 65
print("Enter last alphabet that pattern")
a = 65
for i in range(0, 6):
    for x in range(0, i + 1):
        print(chr(A), end="")
        A += 1

    print("\r")
# 8) Print following pattern
#
# #
# # #
thr = "#"
for i in range(0, 3):
    for x in range(0, i + 1):
        print(thr, end="")
    print("\r")


# 9) Write function to accept the named arguments and print those functions.
def namee(name):
    print(name)


x = input("Enter Nmae   ")
namee(x)

# 8 ) Use the math module and get the squrte root of 64.
import math

print("Enter number to find its SQR root")
x = input()
print(math.sqrt(int(x)))
