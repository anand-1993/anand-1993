def sorting(name):
    name.sort()
    new = ""
    for i in name:
        new = new + i
    return  new

x = input("enter string    ").split()
y = sorting(x)
print(y)