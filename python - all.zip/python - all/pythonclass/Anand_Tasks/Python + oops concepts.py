# 1)  Write in comment what is encapsulation and write program to show encapsulation
# encapsulatiom :
"""
encapsulation is the process of  wrapping up data and methods and hide the
information and methods in the class and prevent accessing it from other class
Encapsulation in Python is the process of wrapping up variables and methods
into a single entity. In programming,
a class is an example that wraps all the variables and methods defined inside it.
>>In Python, Encapsulation can be achieved using Private and Protected Access Members.
Private Members  preceded by using two underscore and Protected
Members preceded by using single underscore

Why Do We Need Encapsulation?
Encapsulation acts as a protective layer by ensuring that, access to wrapped
 data is not possible by any code defined
outside the class in which the wrapped data are defined. Encapsulation
provides security by hiding the data from the outside world.
In Python, Encapsulation can be achieved by declaring the data members of
a class either as private or protected. In Python, 'Private' and 'Protected' are
called Access Modifiers, as they modify the access of variables or methods
defined in a class. Let us see how access modifiers help in achieving Encapsulation.

"""


# encapsulation using private members:

class rectangle:
    def __init__(self, x, y):
        self.__x = x
        self.__y = y
        self.a = 10
        self.b = 12

    def __area(self):
        return self.__x * self.__y

    def _area1(self):
        return self.b * self.a


class part(rectangle):
    #  super().__init__(x, y)

    def data(self):
        super().__area()  # AttributeError: 'super' object has no attribute '_part__area'


#        super().area1()


p = part(15, 10)
p.data()

# print("enter value two values")
# x = input().split()
rect = rectangle(12, 10)
rect.area()


# # encapsulation using protected members:
class addition:
    def __init__(self):
        return self

    def _sum(self):
        print("this is ADDITION class")


class arith(addition):
    def __init__(self):
        addition.__init__(self)
        print("protect method is called from addition is  ", self._sum())


a = arith()

# 2) Write in comment what is inheritance and write program to show inheritance
"""Inheritance is the concept of acquiring propeties from other classess, 
a class is being inherited is the base class and a class inheriting is called inherited class """


class person:
    def __init__(self, fname, lname):
        self.fname = fname
        self.lname = lname
        self.age = 29

    def mydata(self):
        return self.fname


class student(person):
    def __init__(self, fname, lname, age):
        super().__init__(fname, lname)
        self.age = age

    def show(self):
        return self.lname


p = person("amol", "bhai")
print(p.mydata())
s = student("anand", "som", 28)
print(s.show())
print(s.fname)
print(s.mydata())


# 3 )Write in comment what is inheritance types and write program to show all types inheritance
# 1) Single Inheritance
# 2) Multi-level Inheritance
# 3) Multiple Ihneritance
# Single Inheritance
class fruit:
    def __init__(self, dry, jucey):
        self.dry = dry
        self.jucey = jucey


class summer(fruit):
    def __init__(self, dry, jucey):
        self.dry = dry
        self.jucey = jucey
        pass


class winter(summer):
    pass


class banana(fruit):
    pass


m = winter("badab", "mango")
print(m.jucey)
b = banana("walnut", "orange")
print(b.dry)

# 4 ) Write in comment what is private public, protected variable
# and write program to use public private and protected variable
"""
Private variable >> a variable which can not accees by any other class 
only the class in which that varible is declared can access the variable is called prvate variable

Protected varible >>  a varibale which can accees only a class in which the variable 
is declared as protected and the class that is derived from the class in which protected varible is declard. """


class varibale:
    __c = 10  # using double underscore we declared private varible
    _h = 100  # using double underscore we declared protected varible

    def __init__(self, value):
        self.a = value  # public variable
        self.b = b

    print("we are in base class")


class acees(varibale):
    def __init__(self, value):
        super().__init__(value)
        self.value = value
        #        print("we are in derived class and accessing private mebers is  ", self.__c)  # eror
        print("we are in derived class and  accessing protected members is ", self._h)


v = varibale(45)
a = acees(12)

# 5) write in comment what is static variable and write program to use static variables

""" If the value of a variable is not varied from object to object, such types of variables we have to declare within the 
class directly but outside of methods. Such types of variables are called Static variables.
For the entire class, only one copy of the static variable will be created and shared by all 
objects of that class. We can access static variables either by class name or by object reference.
 But recommended using the class name. """


class test:
    var = 10  # #Declaring static variable directly in the class but from outside of the method


print(test.__dict__)


# Inside constructor by using the class name :
# Once we declare the static variable inside the constructor by using the class name,
# we have to create an object, then automatically the python prints the static variable.
class test1:
    a = 10

    def __init__(self):
        test1.b = 15  # Inside constructor by using the class name

        print(test1.__dict__)


t = test1()


# Inside the instance method by using the class name

class test2:
    a = 10

    def __init__(self):
        pass

    def meth(self):
        test2.d = 45  # Inside the instance method by using the class name
        print(test2.__dict__)  ##You can see that c=30 will be added to the class dictionary in the below output
        print(test2.d)


t1 = test2()
t1.meth()  # # Calling instance method will prints the static variable


# 6) Write in comment what is polymorphism and write program to show polymorphism. Take Person and manager example.

# polymorphism is a concept of functioning for different implementation that means taking many forms for different types .
# method overriding is example in derived class for polymorphism.


class person:
    def __init__(self, name):
        self.name = name

    def show(self):
        print("this show function printing name of person class is   ", self.name)


class manager(person):
    def __init__(self, name):
        self.name = name

    def show(self):
        print("this show function printing name of manager class is  ", self.name)


p = person("Anand")
p.show()
m = manager("david")
m.show()

# 7) Write in comment what is Abstraction and write program to show Abstraction. Take Shape example

# Abstraction is the concept of hiding information , knowledge ,functioning
# from user and providing common interface for diffrent implementation.
# by defining abstract base class you can implement commom aplication program interface
# for its subclasses

from abc import ABC, abstractmethod


class shape(ABC):
    @abstractmethod
    def area(self):
        pass


class rectangle(shape):
    def __init__(self, l, b):
        self.l = l
        self.b = b

    def area(self):
        return self.l * self.b


class triangle(shape):
    def __init__(self, l, w):
        self.l = l
        self.w = w

    def area(self):
        return 0.5 * self.l * self.w


class square(shape):
    def __init__(self, s):
        self.s = s

    def area(self):
        return self.s * self.s


# s = shape()
t = triangle(15, 10)
print(t.area())
s = square(5)
print(s.area())
