# Python JSON
# JSON is a syntax for storing and exchanging data.
# JSON is text, written with JavaScript object notation.
# JSON in Python
# Python has a built-in package called json, which can be used to work with JSON data.
# Import the json module:
# Parse JSON - Convert from JSON to Python
# If you have a JSON string, you can parse it by using the json.loads() method.
# The result will be a Python dictionary.
import json

# some JSON:
"""x = '{ "name":"John", "age":30, "city":"New York"}'

# parse x:
y = json.loads(x)

# the result is a Python dictionary:
print(y["age"])"""

"""x = '{def arith(*args):
    def ope():
        val = 15
        result = int(args[0]) * val
        print(result)

    return ope
p = arith(10)}"""
