# 1) Define dictionary with float , int , list and tuple.
dict = {"flaot" : 10.23, "int" : 54, "List" : ["anand", "som"], "Tpl": ("java", "python")}
print(dict)

# 2) find the symmetric difference between followoing set
firstSet = { 1, 2, 3,5}
secondSet = { 1, 2, 3,4}
print(firstSet.symmetric_difference(secondSet))

# 3) Find the union on the two sets using or operator.
firstSet = { 1, 2, 3,5}
secondSet = { 1, 2, 3,4}
print(firstSet | secondSet)

# 4) Find the common element between two sets using and operator
print(firstSet & secondSet)
# 5) Find the different in set using minus operator
print(firstSet - secondSet)

# 6) print the name value from following dictionary
dictt = { "name" : "1", "age" : "3"}
print(dictt["name"])
# 7) Update following dictionary with place an key and value as Akl
dictt.update({"place" : "Akl"})
print(dictt)
# 8) Update following dictionary with students an key and [{ "name" :"p1"}]
dictt.update({"students": [{"nsme" : "p1"}]})
print(dictt)
# 9) Print only keys from following dictionary
print(dictt.keys())
# 10) Print only valyes from following dictionary
print(dictt.values())

# 11) Create dictionary using fromkeys method.
test = ("test","test1")
value = "1"
newdict = dict.fromkeys(test,value)
print(newdict)

# 12) Remove name from following dictionary
dict ={ "name" : "1", "age" :"3"}
dict.pop("name")
print(dict)
# 13) Define dictionary with list and update that list using append method.
dis = {"t1" : []}
for i in range(1, 5):
    dis["t1"].append(i)
print(dis["t1"])
