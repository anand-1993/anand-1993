# 1) Take input from user and validate the number in
# decorater and two manipulation on that input value .
def mal(data):
    def additon():
        y = 15
        add = y + data()
        return add

    return additon


@mal
def input_user():
    print("enter number")
    x = int(input())
    return x


print(input_user())


# 2) Take input from user and typecast to the int , write decorate for checking that number is not negative .
# it not negative check that is even nunber or odd number and print the nunber
def test(numcheck):
    def testing():
        a = numcheck()
        if a < 0:
            return print("yes it is negative")
        elif a % 2 == 0:
            return print("yes it is even number")
        else:
            return print("it is odd number")

    return testing


@test
def input_number():
    print("enter number")
    x = int(input())
    return x


print(input_number())


# 3) use same decorator for two or more methods.
def dictdeco(addnew):
    def myinfo():
        d = addnew()
        dict2 = {"city": "nagpur"}
        dict2.update(d)
        return dict2

    return myinfo


@dictdeco
def data():
    dict = {"Name": "annad", "Age": 28}
    return dict


print(data())


@dictdeco
def info():
    dict1 = {"Lang": "Pythion", "exp": 0}
    return dict1


print(info())


# 4)Create 1 module and 1 package create decorator method in that module (package).
# Write function in another modoule and import decorator into anothe module and use it.
# Use 2 program in this.
def argu(data):
    def func(*args):
        if args and len(args) == 0:
            value = data(args[0])
            return 1
        else:
            value = data(args[0])
        if value == 0 or value == 1:
            return 1
        else:
            return value * func(value - 1)

    return func


# from module1 import *
@argu
def facto(x):
    return x


p = int(input("enter input "))
print(facto(p))
# 5) Generate output like following
#  *
# ***
print("enter no of rows")
x = int(input())
space = x - 1
for i in range(x):
    for j in range(space):
        print(end=" ")
    space = space - 1
    for z in range(i + 1):
        print("*", end=" ")
    print("\r")

# 6) Merging two sorted list
a = [3, 4, 6, 10, 11, 18]
b = [1, 5, 7, 12, 13, 19, 21]
a.extend(b)
a.sort()
print(a)


# 7) Write to program to check number is prime or not.
# please use decorators for checking input is int or valid integer
def primech(data):
    def check(*args):
        flag = False
        if args[0] == 2:
            return print("it is even prime number")
        else:
            for i in range(2, args[0]):
                if args[0] % i == 0:
                    flag = True
                    break
        if flag:
            return print("it is not prime")
        else:
            return print("it is prime")

    return check


@primech
def numchek(x):
    return x


print("enter number")
p = int(input())
numchek(p)
# 8) Find Maximum number from two numbers .
print("enter number")
x = input().split()
if int(x[0]) > int(x[1]):
    print(x[0], " is Greater")
else:
    print(x[1], "is Greater")


# 9) Write program for simple interest. Use decorators for validating inputs
def indeco(data):
    def form(*args):
        result = int(args[0][0]) * int(args[0][1]) * int(args[0][2]) / 100
        return result

    return form


@indeco
def intrest(x):
    return x


print("Enter Principle, Rate and Time respectively")
p = input().split()
print(intrest(p))

# 10) Write program for find area of circle
print("enter radius")
x = float(input())
v = (22 / 7) * x * x
print("area of circle is ", v)

# 11) [10,12,12,1,1,3,5,5] Find the largrest element from array.

list1 = [10, 12, 12, 1, 1, 3, 5, 5]
list1.sort()
print("largest element is ", list1[len(list1) - 1])

# 12) Write program for reversing list
file = [10, 12, 12, 1, 1, 3, 5, 5]
file.reverse()
print(file)

# 13) write program to print words with length even number from string
#
input = "a b ab bc python test program for finding the even numbers".split()
for i in input:
    if len(i) % 2 == 0:
        print(i, end=" ")