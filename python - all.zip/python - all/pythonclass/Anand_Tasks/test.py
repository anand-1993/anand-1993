from temp import *
someModuleFunction3()
from temp import someModule2Function as sm2
someModule2Function()
sm2()
