def rev(name):
    count = 0
    temp = ""
    new = ""
    for i in name:
        for x in name:
            if i == x:
                count += 1
                continue
        if count >  1 :print("Enter values")
x =input().split()
v = []
for i in x:
        try:
                if not type(i) is int:
                        raise TypeError("trying to add string , integer value expected")

            new += i
        count = 0
    for i in name:
        if  i not in new:
            temp += i
    return temp
    print(temp)




x = input("enter string   ")
print("string without similer character is", rev(x))