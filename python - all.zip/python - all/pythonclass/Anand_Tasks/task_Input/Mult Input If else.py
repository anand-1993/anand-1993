# 1)Write program to multiplications.
#Accept two field using input method.
print("Enter value for Mul")
x = int(input())
y = int(input())
print("Mul is ", x*y)

# 2) Accept multiple fiels from user and do division of numbers.
print("Enter Values")
x = input().split()
print(float(x[0])/float(x[1]))

# 3) Write program for if else conditions.
# x = 10 and x = 20 , x = 30 , x=50
# write If else statement for printing x= 10 so on...
print("Enter Value from (10, 20, 30, 50)")
x = int(input())
if x == 10:
    print("It is 10")
elif x == 20:
    print("it is 20")
elif x ==30:
    print("it is 30")
elif x ==50:
    print("it is 50")
else:
    print("invalid input")

# 4) Write program to print x value if it < 10 else print "all done"
print("enter value less than 10")
x = int(input())
if x < 10:
    print(x)
else:
    print("all done")

# 5) y = 3 write program that y is positive using if and else
y = 3
if y > 0:
    print("it is positive")
else:
    print("it is negative")

# 6) y = -1 write program to check y is negative number
y = -1
print(y < 0)