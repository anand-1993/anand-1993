# 1)Check if 1 is present on list
li = [1,2,3,'a','b','c']
for i in li:
    if i ==1:
        break
print( i ==1)

# 2) Create the single list from following list
# 1st way
name = ['Snowball', 'Chewy', 'Bubbles', 'Gruff']
animal = ['Cat', 'Dog', 'Fish', 'Goat']
age = [1, 2, 2, 6]
info = name + animal + age
print(info)
# 2nd way
name.extend(animal)
name.extend(age)
print(name)

# 2) sort the list
numberList= [7,10,11,1, 2, 2, 6]
print(numberList.sort(), numberList)

# 3) reverse the list
# 1st way
numberList= [7,10,11,1, 2, 2, 6]
print(numberList[: : -1])
# 2nd way
k =[]
for i in reversed(numberList):
    k.append(i)
print(k)

# 4) Find the goat from list using negative index
animal = ['Cat', 'Dog', 'Fish', 'Goat']
print(animal[-1])

# 5) nd the goat and Fish from list using negative index
animal = ['Cat', 'Dog', 'Fish', 'Goat']
print(animal[-2 : : ])

# 6) Find last element from following list.
numberList= [7,10,11,1, 2, 2, 6]
for i in numberList:
    if i == len(numberList) - 1:
        break
print(i)

# 7) nsert at first position
numberList= [7,10,11,1, 2, 2, 6]
print("Enter Value at first position")
x = int(input())
numberList.insert(0,x)
print(numberList)

# 8) Insert at last position
numberList= [7,10,11,1, 2, 2, 6]
print("Enter Value at Last position")
x = int(input())
numberList.insert(len(numberList) ,x)
print(numberList)

# 9) Create Copy of following list and print both the list.
numberList= [7,10,11,1, 2, 2, 6]
numberList1 = numberList.copy()
print(numberList, numberList1)

# 10) Append element at last
numberList= [7,10,11,1, 2, 2, 6]
numberList.append(65)
print(numberList)

# 11) Append element at first
numberList= [7,10,11,1, 2, 2, 6]
numberList.insert(0, 98)
print(numberList)

# 12) delete 1 from list
numberList= [7,10,11,1, 2, 2, 6]
for i in numberList:
    if i == 1:
        numberList.remove(i)
        break
print(numberList)

# 13) Find the occurences of 2 in following list
numberList= [7,10,11,1, 2, 2, 6]
count =0
for i in numberList:
    if i == 2:
        count += 1
        continue
print("Occurences of 2 is ",count)

# 14) Merge the two list and sort that list
numberList= [7,10,11,1, 2, 2, 6]
numberList1 = [9,1,4,8]
numberList.extend(numberList1)
print(numberList.sort(), numberList)
# 15 ) Merge the two list and sort that list and remove last element.
print(numberList.pop(), numberList)

# 16) Merge the two list and sort that list and remove last element.
numberList= [7,10,11,1, 2, 2, 6]
numberList1 = [9,1,4,8]
print(numberList.extend(numberList1), numberList.pop(), numberList)

# 17) Remove duplicate from following list.
# 1st way
numberList= [7,10,11,1, 2, 2, 6]
numberList = list(set(numberList))
print(numberList)
# 2nd way
count = 0
flag = False
for i in numberList:
    for x in range(len(numberList)-1):
        if i ==numberList[x]:
            count += 1
            flag = True
            continue
    if flag and count > 1:
        flag = False
        count = 0
        numberList.remove(i)
print(numberList)

# 18) Merge following list and reverse the list
numberList= [7,10,11,1, 2, 2, 6]
numberList1 = [9,1,4,8,3,2,2]
numberList.extend(numberList1)
print(numberList.reverse(),numberList)

# 19) Remove all element from list
numberList= [7,10,11,1, 2, 2, 6]
print(numberList.clear(), numberList)

# 20) Merge following list and remove test element from following.
numberList= [7,10,11,1, 2, 2, 6]
Tuple= ("test","test1")
numberList.extend(Tuple)
print(numberList.remove("test"), numberList)

# 21) Find the length list of following elements.
numberList= [7,10,11,1, 2, 2, 6]
print(len(numberList))

# 22) Reverse the list using negative index
numberList= [7,10,11,1, 2, 2, 6]
print(numberList[: : -1])

# 23) insert element at middle position.
numberList= [7,10,11,1, 2, 2, 6]
x = int(len(numberList)/2)
numberList.insert(x, 98)
print(numberList)