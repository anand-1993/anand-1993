"""# Write program to multiplications.
# Accept two field using input method.
print( "Enter Two Number")
x = input()
y = input()
print("Mul is", int(x) * int(y))

# Accept multiple fiels from user and do division of numbers.
print("Enter Number ")
x, y = input().split()
print("Div Is", float(x)/float(y))
# Write program for if else conditions.
# x = 10 and x = 20 , x = 30 , x=50
# write If else statement for printing x= 10 so on...
y = input("Enter numer ")
x = int(y)
if   x == 10:
    print("Yes it is 10")
elif x == 20:
    print("yes it is 20")
elif x == 30:
    print("yes it is 30")
elif x == 50:
    print("yes it is 50")
else:
    print("Number is not available"

# Write program to print x value if it < 10 else print "all done"
print("Enter number")
y = input()
x = int(y)
if x < 10:
    print(x)
else:
    print("all done")"""

# y = 3 write program that y is positive using if and else
y = 3
if y > 0:
    print("Number Is Positve")
else:
    print("Number is negative")

# y = -1 write program to check y is negative number
y = -1
if y > 0 :
    print("positive")
else:
    print("negative")