# Python OOPs Concepts
# In Python, object-oriented Programming (OOPs) is a programming paradigm that uses objects
# and classes in programming. It aims to implement real-world entities like inheritance,
# polymorphisms, encapsulation, etc. in the programming. The main concept of OOPs is to bind
# the data and the functions that work on that together as a single unit so that no other part of the code can access this data.
# Main Concepts of Object-Oriented Programming (OOPs)
# Class
# Objects
# Polymorphism
# Encapsulation
# Inheritance
# Some points on Python class:
# Classes are created by keyword class.
# Attributes are the variables that belong to a class.
# Attributes are always public and can be accessed using the dot (.) operator. Eg.: Myclass.Myattribute
# Example: Creating an empty Class in Python

# Python3 program to
# demonstrate defining
# a class

class Dog:
    pass


# In the above example, we have created a class named dog using the class keyword.
# Objects
# The object is an entity that has a state and behavior associated with it.
# It may be any real-world object like a mouse, keyboard, chair, table, pen, etc. Integers, strings, floating-point numbers,
# even arrays, and dictionaries, are all objects. More specifically, any single integer or any single string is an object.
# The number 12 is an object, the string “Hello, world” is an object, a list is an object that can hold other objects, and so on.
# You’ve been using objects all along and may not even realize it.

# ****** An object consists of :
"""State: It is represented by the attributes of an object. It also reflects the properties of an object.
Behavior: It is represented by the methods of an object. It also reflects the response of an object to other objects.
Identity: It gives a unique name to an object and enables one object to interact with other objects."""

""" To understand the state, behavior, and identity let us take the example of the class dog (explained above). 
The identity can be considered as the name of the dog.
State or Attributes can be considered as the breed, age, or color of the dog.
The behavior can be considered as to whether the dog is eating or sleeping."""


# Example: Creating an object
class Dog:
    obj = Dog()


# This will create an object named obj of the class Dog defined above. Before diving deep into objects and class let us understand
# some basic keywords that will we used while working with objects and classes.

"""The self  
Class methods must have an extra first parameter in the method definition. 
We do not give a value for this parameter when we call the method, Python provides it
If we have a method that takes no arguments, then we still have to have one argument.
This is similar to this pointer in C++ and this reference in Java.
When we call a method of this object as myobject.method(arg1, arg2), 
this is automatically converted by Python into MyClass.method(myobject, arg1, arg2) – this is all the special self is about."""


# The __init__ method
# The __init__ method is similar to constructors in C++ and Java.
# It is run as soon as an object of a class is instantiated.
# The method is useful to do any initialization you want to do with your object.
# Now let us define a class and create some objects using the self and __init__ method.

# Example 1: Creating a class and object with class and instance attributes
class Dog:
    # class attribute
    attr1 = "mammal"

    # Instance attribute
    def __init__(self, name):
        self.name = name


# Driver code
# Object instantiation
Rodger = Dog("Rodger")
Tommy = Dog("Tommy")
# Accessing class attributes
print("Rodger is a {}".format(Rodger.__class__.attr1))
print("Tommy is also a {}".format(Tommy.__class__.attr1))

# Accessing instance attributes
print("My name is {}".format(Rodger.name))
print("My name is {}".format(Tommy.name))


# Use the __init__() function to assign values to object properties, or
# other operations that are necessary to do when the object is being created:
# Note: The __init__() function is called automatically every time the class is being used to create a new object.

# Object Methods
# Objects can also contain methods. Methods in objects are functions that belong to the object.
# Let us create a method in the Person class:
class emp:
    def __init__(self, name, id, salary):
        self.name = name
        self.id = id
        self.salary = salary

    def info(self):
        print("salalry is", self.salary)


obj1 = emp("Anand", 56325, 80000)
obj1.info()
print(obj1.name, obj1.salary, obj1.id)


# Note: The self parameter is a reference to the current instance of the class,
# and is used to access variables that belong to the class.
# The self Parameter
# The self parameter is a reference to the current instance of the class, and is used to access variables that belongs to the class.
#
# It does not have to be named self , you can call it whatever you like, but it has to be the first parameter of any function in the class:

class shape:
    def __init__(acces, name, diagram):
        acces.name = name
        acces.diagram = diagram

    def area(angle):
        print("Angle is", angle.name)


sh1 = shape("Triangle", "Three lines")
sh1.area()
print(sh1.name, "\n", sh1.diagram)

# Modify Object Properties
# You can modify properties on objects like this:
sh1.name = "Rectangle"
print(sh1.name)
# Delete Object Properties
# You can delete properties on objects by using the del keyword:
# del sh1.name
print(sh1.name)


# Delete Objects
# You can delete objects by using the del keyword:
# del sh1


# The pass Statement
# class definitions cannot be empty, but if you for some reason have a class definition with no content,
# put in the pass statement to avoid getting an error.

class Person:
    pass


class Person:
    age = 30

    def __init__(self, name):
        self.name = name
        print("call")

    def getName(self):
        return self.name


# self : Used to access current object or property of object withing class.
person = Person("Python")
person1 = Person("JavaScript")

print(person.__dict__)
# Instance variable = Variable which are writtern inside __init__ method called instance variable
print(person.getName())

print(person1.__dict__)

# Static Variable/Class Variables
# Static variable :
print(Person.age)
print(person.age)

# Static Variable/Class Variables
# Static variable :
print(person1.age)

# Memory of static variable. It should be same. beacuse static variables get
# shared across the object/instance.
print(id(Person.age))
print(id(person.age))
print(id(person1.age))

# Memory of Instance variable. It should be different. beacuse instance variables
# different for different object/instance.
print(id(person.name))
print(id(person1.name))
# 1) What is object oriented langauge ( Write down in comment session.)
""" In Python, object-oriented Programming (OOPs) is a programming paradigm that uses objects
 and classes in programming. It aims to implement real-world entities like inheritance,
 polymorphisms, encapsulation, etc. in the programming. The main concept of OOPs is to bind
 the data and the functions that work on that together as a single unit so that no other part of the code can access this data."""


# 2) Create Peson class and instacne variable and static variables in it.
class Peson:
    name = "Anand"  # static variable

    def __init__(self, age):
        self.age = age  # instance variable


# 3) Create List Class and add item name and item count in that class.
# a) Create method in class to return item name and item count .
# b) b. write contructor and also destructor
# c) Write method to return value using self.
# d) create object and print values.
class List:
    def __init__(self, name, count):
        self.name = name
        self.count = count

    def getname(self):
        return self.name

    def getcount(self):
        return self.count

    def __del__(self):
        print("there is no structure")


l1 = List("anand", 0)
print(l1.getname(), l1.getcount())
print(l1.name)
print(l1.count)


# INHERITANCE#
# Inheritance allows us to define a class that inherits all the methods and properties from another class.
# Parent class is the class being inherited from, also called base class.
# Child class is the class that inherits from another class, also called derived class.
# Create a Parent Class
# Any class can be a parent class, so the syntax is the same as creating any other class:
# example
class student:
    def __init__(self, fname, lname):
        self.firstname = fname
        self.lasttname = lname

    def printname(self):
        print(self.firstname, self.lasttname)


s1 = student("anand", "somkuwar")
s1.printname()


# Create a Child Class
# To create a class that inherits the functionality from another class,
# send the parent class as a parameter when creating the child class:

# Create a class named boys, which will inherit the properties and methods from the Person class:


# class boys(student):


# Note: Use the pass keyword when you do not want to add any other properties or methods to the class.

# Now the Student class has the same properties and methods as the Person class.
# b1 = boys("amol", "pisode")
# b1.printname()

# Add the __init__() Function
# So far we have created a child class that inherits the properties and methods from its parent.
# We want to add the __init__() function to the child class (instead of the pass keyword).
# Note: The __init__() function is called automatically every time the class is being used to create a new object.
# Add the __init__() function to the boys class:
class boys(student):
    def __init__(self, fname, lname):
        student.__init__(self, fname, lname)


#  When you add the __init__() function, the child class will no longer inherit the parent's __init__() function.\
# Note: The child's __init__() function overrides the inheritance of the parent's __init__() function.
# To keep the inheritance of the parent's __init__() function, add a call to the parent's __init__() function:
b1 = boys("anand", "som")
b1.printname()


# Now we have successfully added the __init__() function,
# and kept the inheritance of the parent class, and we are ready to add functionality in the __init__() function.
# Use the super() Function
# Python also has a super() function that will make the child class inherit all the methods and properties from its parent:
class girls(student):
    def __init__(self, fname, lname, year):
        super().__init__(fname, lname)
        self.graduationyear = year

    def welcome(self):
        print("welcome", self.firstname, self.lasttname, " to the", self.graduationyear)


# By using the super() function, you do not have to use the name of the parent element,
# it will automatically inherit the methods and properties from its parent.


g1 = girls("sapna", "sharma", 2017)
g1.printname()
print(g1.graduationyear)
g1.welcome()
print(dir(student))
# In the example abov, the year 2017 should be a variable, and passed into
# the girls class when creating girls objects. To do so, add another parameter in the __init__() function:
# Add Methods


# *** ABSTRACT
# Abstract Classes in Python
""" An abstract class can be considered as a blueprint for other classes. 
It allows you to create a set of methods that must be created within any 
child classes built from the abstract class.  A class which contains one or more 
abstract methods is called an abstract class.  An abstract method is a method that
 has a declaration but does not have an implementation.  While we are designing 
 large functional units we use an abstract class. When we want to provide a common 
 interface for different implementations of a component, we use an abstract class."""

"""Why use Abstract Base Classes : 
By defining an abstract base class, you can define a common Application Program Interface(API) for a set of subclasses. 
This capability is especially useful in situations where a third-party is going to provide implementations, such as with plugins,
 but can also help you when working in a large team or with a large code-base where keeping all classes in your mind is 
 difficult or not possible."""

""" How Abstract Base classes work : 
By default, Python does not provide abstract classes. Python comes with a module 
that provides the base for defining Abstract Base classes(ABC) and that module name is ABC. 
ABC works by decorating methods of the base class as abstract and then registering concrete 
classes as implementations of the abstract base. A method becomes abstract when decorated 
with the keyword @abstractmethod."""

""" Encapsulation :
1) What is Encapsulation in Python?
Encapsulation in Python is the process of wrapping up variables and methods into a single entity. In programming, 
a class is an example that wraps all the variables and methods defined inside it.
2) How can we achieve Encapsulation in Python?
In Python, Encapsulation can be achieved using Private and Protected Access Members.
3) How can we define a variable as Private?
In Python, Private variables are preceded by using two underscores.
4) How can we define a variable as Protected?
In Python, Protected variables are preceded by using a single underscore.

Encapsulation in Python is the process of wrapping up variables and methods into a single entity.
In programming, a class is an example that wraps all the variables and methods defined inside it.

In the real world, consider your college as an example. Each and every department's student records 
are restricted only within the respective department. 
CSE department faculty cannot access the ECE department student record and so on. 
Here, the department acts as the class and student records act like variables and methods.
Before understanding its working, let us look at the advantages of using Encapsulation in programs.

Why Do We Need Encapsulation?
Encapsulation acts as a protective layer by ensuring that, access to wrapped data is not possible by any code defined 
outside the class in which the wrapped data are defined. Encapsulation provides security by hiding the data from the outside world.
In Python, Encapsulation can be achieved by declaring the data members of a class either as private or protected. In Python, 'Private' and 'Protected' are called Access Modifiers, as they modify the access of variables or methods defined in a class. Let us see how access modifiers help in achieving Encapsulation.

Encapsulation Using Private Members
If we declare any variable or method as private, then they can be accessed only within 
the class in which they are defined. In Python, private members are preceded by two underscores. 
In the below example, 'length' and 'breadth' are the two private variables declared 
and can be accessed within the class 'Rectangle'."""


class Rectangle:
    __length = 0  # private variable
    __breadth = 0  # private variable


def __init__(self):  # constroctor
    self.__length = 5
    self.__breadth = 3
    # #printing values of the private variable within the class
    print(self.__length)
    print(self.__breadth)


rec = Rectangle()  # object created for the class 'Rectangle'
# printing values of the private variable outside the class using the object created for the class 'Rectangle'
print(rec.length)
print(rec.breadth)
# output
""" Traceback (most recent call last):
  File "/home/anand/pythonclass/Anand_Tasks/class_object_method.py", line 186, in <module>
    print(rec.length)
AttributeError: 'Rectangle' object has no attribute 'length'"""

"""Since we have accessed private variables in the main() method,
i.e., outside the class 'Rectangle', we got an error.
Hence in the above program, Encapsulation is achieved using the private
variables 'length' and 'breadth'. Next, let us see how to achieve Encapsulation using protected members."""


# Encapsulation Using Protected Members #

# Protected members can be accessed within the class in which they are defined and also within the derived classes.In Python,
# protected members are preceded by a single underscore.
# In the below example, 'length' and 'breadth' are the two protected variables defined inside the class 'Shape'.

class Shape:  # protected variables
    _length = 10
    _breadth = 20


class Circle(Shape):
    def __init__(self):  # printing protected variables in the derived class
        print(self._length)
        print(self._breadth)


cr = Circle()
# printing protected variablesoutsidethe class 'Shape' in which they are defined
print(cr.length)
print(cr.breadth)
"""hen we try to access protected variables in the derived class, we got output. 
But, in the main() method, we got an error. Hence in the above example, 
Encapsulation is achieved using the protected variables 'length' and 'breadth'."""

# Polymorphism
""" What is Polymorphism: The word polymorphism means having many forms. 
In programming, polymorphism means the same function name (but different 
signatures) being used for different types."""
# Example of inbuilt polymorphic functions :
# Python program to demonstrate in-built poly-
# morphic functions
# len() being used for a string
print(len("geeks"))
# len() being used for a list
print(len([10, 20, 30]))


# Examples of user-defined polymorphic functions :
# A simple Python function to demonstrate
# Polymorphism
def add(x, y, z=0):
    return x + y + z


# Driver code
print(add(2, 3))
print(add(2, 3, 4))


# Polymorphism with class methods:
class India():
    def capital(self):
        print("New Delhi is the capital of India.")

    def language(self):
        print("Hindi is the most widely spoken language of India.")

    def type(self):
        print("India is a developing country.")


class USA():
    def capital(self):
        print("Washington, D.C. is the capital of USA.")

    def language(self):
        print("English is the primary language of USA.")

    def type(self):
        print("USA is a developed country.")


obj_ind = India()
obj_usa = USA()
for country in (obj_ind, obj_usa):
    country.capital()
    country.language()
    country.type()
""" Polymorphism with Inheritance: 
In Python, Polymorphism lets us define methods in the child class that have 
the same name as the methods in the parent class. In inheritance, the child 
class inherits the methods from the parent class. However, it is possible to 
modify a method in a child class that it has inherited from the parent class. 
This is particularly useful in cases where the method inherited from the parent 
class doesn’t quite fit the child class. In such cases, we re-implement the method 
in the child class. This process of re-implementing a method in the child class is known as Method Overriding. """


class Bird:
    def intro(self):
        print("There are many types of birds.")


def flight(self):
    print("Most of the birds can fly but some cannot.")


class sparrow(Bird):
    def flight(self):
        print("Sparrows can fly.")


class ostrich(Bird):
    def flight(self):
        print("Ostriches cannot fly.")


obj_bird = Bird()
obj_spr = sparrow()
obj_ost = ostrich()

obj_bird.intro()
obj_bird.flight()

obj_spr.intro()
obj_spr.flight()

obj_ost.intro()
obj_ost.flight()


# Polymorphism with a Function and objects:
# It is also possible to create a function that can take any object, allowing for polymorphism.
# In this example, let’s create a function called “func()” which will take an object which we will
# name “obj”. Though we are using the name ‘obj’, any instantiated object will be able to be called
# into this function. Next, let’s give the function something to do that uses the ‘obj’ object we passed to it.
# In this case, let’s call the three methods, viz., capital(), language() and type(), each of which is defined in the
# two classes ‘India’ and ‘USA’. Next, let’s create instantiations of both the ‘India’ and ‘USA’ classes if we don’t
# have them already. With those, we can call their action using the same func() function:
def func(obj):
    obj.capital()
    obj.language()
    obj.type()


obj_ind = India()
obj_usa = USA()

func(obj_ind)
func(obj_usa)


# Code: Implementing Polymorphism with a Function
class India():
    def capital(self):
        print("New Delhi is the capital of India.")

    def language(self):
        print("Hindi is the most widely spoken language of India.")

    def type(self):
        print("India is a developing country.")


class USA():
    def capital(self):
        print("Washington, D.C. is the capital of USA.")

    def language(self):
        print("English is the primary language of USA.")

    def type(self):
        print("USA is a developed country.")


def func(obj):
    obj.capital()
    obj.language()
    obj.type()


obj_ind = India()
obj_usa = USA()

func(obj_ind)
func(obj_usa)


# Below is a program to illustrate the use of all the above
# three access modifiers (public, protected, and private) of a class in Python:
# program to illustrate access modifiers of a class

# super class
class Super:
    # public data member
    var1 = None

    # protected data member
    _var2 = None

    # private data member
    __var3 = None

    # constructor
    def __init__(self, var1, var2, var3):
        self.var1 = var1
        self._var2 = var2
        self.__var3 = var3

    # public member function
    def displayPublicMembers(self):
        # accessing public data members
        print("Public Data Member: ", self.var1)

    # protected member function
    def _displayProtectedMembers(self):
        # accessing protected data members
        print("Protected Data Member: ", self._var2)

    # private member function
    def __displayPrivateMembers(self):
        # accessing private data members
        print("Private Data Member: ", self.__var3)

    # public member function
    def accessPrivateMembers(self):
        # accessing private member function
        self.__displayPrivateMembers()


# derived class
class Sub(Super):

    # constructor
    def __init__(self, var1, var2, var3):
        Super.__init__(self, var1, var2, var3)

    # public member function
    def accessProtectedMembers(self):
        # accessing protected member functions of super class
        self._displayProtectedMembers()


# creating objects of the derived class
obj = Sub("Geeks", 4, "Geeks !")

# calling public member functions of the class
obj.displayPublicMembers()
obj.accessProtectedMembers()
obj.accessPrivateMembers()

# Object can access protected member
print("Object is accessing protected member:", obj._var2)

# object can not access private member, so it will generate Attribute error
# print(obj.__var3)
