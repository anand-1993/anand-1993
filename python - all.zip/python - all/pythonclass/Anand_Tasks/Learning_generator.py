# Generators in Python
# Prerequisites: Yield Keyword and Iterators
# There are two terms involved when we discuss generators.
# 1) Generator-Function : A generator-function is defined like a normal function,
# but whenever it needs to generate a value, it does so with the yield keyword rather than return.
# If the body of a def contains yield, the function automatically becomes a generator function.
def simpleGeneratorFun():
    yield 1
    yield 2
    yield 3


# Driver code to check above generator function
for value in simpleGeneratorFun():
    print(value)

# Generator-Object : Generator functions return a generator object. Generator objects are used either by calling the next method
# on the generator object or using the generator object in a “for in” loop (as shown in the above program).
# A Python program to demonstrate use of
# generator object with next()

# A generator function
"""def simpleGeneratorFun():
    yield 1
    yield 2
    yield 3


# x is a generator object
x = simpleGeneratorFun()

# Iterating over the generator object using next
print(x.next())  # In Python 3, __next__()
print(x.next())
print(x.next())
for value in simpleGeneratorFun():
    print(value)"""

# Iter()
# python iter() method returns the iterator object, it is used to convert an iterable to the iterator.
# Properties of Iterators
# Iteration object remembers iteration count via internal count variable.
# Once the iteration is complete, it raises a StopIteration exception and the iteration count cannot be reassigned to 0.
# Therefore, it can be used to traverse the container just once.
# Python iter() Example
# Python3 code to demonstrate
# working of iter()

# initializing list
"""lis1 = [1, 2, 3, 4, 5]

# printing type
print("The list is of type : " + str(type(lis1)))

# converting list using iter()
lis1 = iter(lis1)
# printing type
print("The iterator is of type : " + str(type(lis1)))

# using next() to print iterator values
print(next(lis1))
print(next(lis1))
print(next(lis1))
print(next(lis1))
print(next(lis1))
# Python 3 code to demonstrate
# property of iter()

# initializing list
lis1 = [1, 2, 3, 4, 5]

# converting list using iter()
lis1 = iter(lis1)

# prints this
print("Values at 1st iteration : ")
for i in range(0, 5):
    print(next(lis1))

# doesn't print this
print("Values at 2nd iteration : ")
for i in range(0, 5):
    print(next(lis1))"""
# Enumerate() in Python
# Often, when dealing with iterators, we also get a need to keep a count of iterations.
# Python eases the programmers’ task by providing a built-in function enumerate() for this task.
# Enumerate() method adds a counter to an iterable and returns it in a form of enumerating object.
# This enumerated object can then be used directly for loops or converted into a list of tuples using the list() method.
# #python
# # Python program to illustrate
# # enumerate function
l1 = ["eat", "sleep", "repeat"]
s1 = "geek"

# # creating enumerate objects
obj1 = enumerate(l1)
obj2 = enumerate(s1)

print("Return type:", type(obj1))
print(list(enumerate(l1)))

# # changing start index to 2 from 0
print(list(enumerate(s1, 2)))

dict = {"name": "anand", "age": 29}
obj = enumerate(dict)
print("return type ", type(obj))
print(list(enumerate(dict)))
