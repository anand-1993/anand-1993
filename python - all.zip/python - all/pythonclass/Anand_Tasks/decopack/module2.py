from module1 import *


@argu
def facto(x):
    return x


p = int(input("enter input "))

print(facto(p))
