def argu(data):
    def func(*args):
        if args and len(args) == 0:
            value = data(args[0])
            return 1
        else:
            value = data(args[0])
        if value == 0 or value == 1:
            return 1
        else:
            return value * func(value - 1)

    return func
