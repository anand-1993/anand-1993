def players (list1):
    print(list1)
print("enter array")
x = input()

players(x)
