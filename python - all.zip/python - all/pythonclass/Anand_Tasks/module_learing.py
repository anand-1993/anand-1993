"""What is a Module?
Consider a module to be the same as a code library.
A file containing a set of functions you want to include in your application."""

# Create a Module
# To create a module just save the code you want in a file with the file extension .py:
def mynoun(name):
   print("your name is \nAnand ", name)
#import module_learning  --- execute on another page
#module_learning.mynou("Somkuwar")
# Variables in Module

# The module can contain functions, as already described,
# but also variables of all types (arrays, dictionaries, objects etc):
person1 = {
  "name": "John",
  "age": 36,
  "country": "Norway"
}
# Re-naming a Module
# You can create an alias when you import a module, by using the as keyword:
import  module_learing as mlx
a = mlx.person1["country"]
print(a)
# Built-in Modules
# There are several built-in modules in Python, which you can import whenever you like.
import platform
a = platform.system()
print(a)
#Using the dir() Function
#There is a built-in function to list all the function names (or variable names) in a module. The dir() function:

a = dir(platform)
print(a)
# Import From Module
# You can choose to import only parts from a module, by using the from keyword.
from module_learing import person1
print(person1["country"])