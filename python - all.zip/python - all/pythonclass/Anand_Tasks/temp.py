class rectangle:
    def __init__(self, x, y):
        self.x = x
        self.y = y

    def area(self):
        print(self.x * self.y)


class parrt(rectangle):
    #  def __init__(self, x, y, name):
    #     super().__init__(x, y)
    #     self.name = name

    def dis(self):
        super().area()
        return self.area()


#  def __init__(self, nav):
#   super().__init__(self)
# self.nav = nav


rect = rectangle(12, 10)
print(rect.area())
p = parrt(10, 10)
# print(p.nav)
# print(p.dis())
p.dis()
