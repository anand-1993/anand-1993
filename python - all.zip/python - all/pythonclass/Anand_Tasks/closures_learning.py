def arith(*args):
    def ope():
        val = 15
        result = int(args[0]) * val
        print(result)

    return ope


p = arith(10)
p()
