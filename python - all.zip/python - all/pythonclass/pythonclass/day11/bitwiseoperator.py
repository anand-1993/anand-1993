
# Bitwise operators
x = 10
y = 10

if x & y:
    print("True")
else:
    print("False")

if x | y:
    print("OR True")
else:
    print("False")

if x ^ y:
    print("True")
else:
    print("False")

true1 = True

if not true1:
    print("Not 2")
else:
    print("Else Part")

#s
# if x | y:
#     print("True")
# else:
#     print("False")

# Computer we have 4 number system
# Decimal :  2 ^10
# Octal : 2^8
# Hexadecimal : 2^16

# Binary : 2^2

a = 12
b = 9

print("Print Bitwise & ")
print(a & b)

#1100
#1001

#1000


a = 20
b = 15

print("Print Bitwise & ")
print(a & b)
#01111
#10100

#00100

a = 20
b = 15

print("Print Bitwise | ")
print(a | b)

#01111
#10100
# Result
#11111



a = 20
b = 15

print("Print Bitwise | ")
print(a | b)

#01111
#10100
# Result
#11111