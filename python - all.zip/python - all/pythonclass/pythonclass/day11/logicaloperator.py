
# Logical operators

a = 30
b = 40

if a == 30 and b == 40:
    print("print ",a)
    print("print ", b)
else:
    print("Else Part")


if a != 30 and b != 40:
    print("print ",a)
    print("print ", b)
else:
    print("Else Part")

# Logical AND

# True True : True
# 1    1    : 1

# True False : False 2
#   1    0    :  0
# False True : False 3
# False False :  False 4


# Logical OR

# True True : True
# 1    1    : 1
# True False : True 2
#   1    0    :  0
# False True : True 3


# False False :  False 4

print("Logical OR")
k = 10
p = 20
if k == 10 or p == 40:
    print("print OR ",k)
    print("print OR", p)
    p=+1
else:
    print("Else Part Logical OR")


print("Logical OR")
k = 10
p = 20
if k == 11 or p == 20:
    print("print OR 2 ",k)
    print("print OR 2", p)
else:
    print("Else Part Logical OR")

if k == 11 or p == 22:
    print("print OR 3 ",k)
    print("print OR 3", p)
else:
    print("Else Part Logical 3 OR")

# OR : any one or . It will result in True
# AND all should True . It will result in True


if k == 10 or p == 22 or k == 11 or p == 22 or k == 11 or p == 22:
    print("Satisfied")

if k == 10 and p == 22 and k == 11 and p == 22 and k == 11 and p == 22:
    print("Satisfied")
else:
    print("Not satisfied")

if k == 10 or (k==10 and p ==22):
    print("Combination of or and")
else:
    print("Combination of or and")

if k == 10 and k==11:
    print("Combination of or and")
else:
    print("Combination else of or and")

if k == 10 or (k==11 and p == 20):
    print("Combination of or and 11111")
else:
    print("Combination else of or and")

# OR : Any one true  It will result in True
# AND : All True then it will results in True

# Not : It will reverse the value.
true1 = True
true2 = True

if not true1:
    print("Not ")
else:
    print("Else Part")

true1 = False
true2 = False

if not true1 and not true2:
    print("Not 2")
else:
    print("Else Part")

