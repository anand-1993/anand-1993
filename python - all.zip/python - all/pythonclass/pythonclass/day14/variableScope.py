
j = 10
i = 10
def scopeVariable():
    global j
    j = j + 1
    print(j)
    k = 100

    def nestedFunction():
        nonlocal k
        global i
        global j
        print("I")
        print(i + 1)
        j = j + 1
        print("J")
        print(j)

        print("K")
        print(k + 1)

    nestedFunction()
    print("outer value of Key:", k)


scopeVariable()

