# class Test:
#     p= 0
#     def test(x,y)
def test(x, y, z):
    # Comments
    print(x)
    print(y)
    print(z)


# def => Definining a function
# function name
# bracket is used for passing argument

# Function call
test(1, 2, 3)


def add(x, y):
    print(x + y)


add(1, 2)
add(2, 3)

print(1 + 2)


def multivalue(y, *x):
    print("Single Value")
    print(y)
    print("Mult- value")
    print(x)

    print("Mult- value")
    for i in x:
        print("access single value from tuple")
        print(i)


multivalue(1, 12, 12, 1, 12, 12, 232, 34, 34, 34, 4, 45, 45, 45, 45, 45, 45, 45, 45, 454, 54, 4545)


def multivalue(*x):
    print("Mult - value 2 function")
    print(x)
    print("Mult- value")
    for i in x:
        print("access single value from tuple - 2 function")
        print(i)


multivalue(1, 2, 3, 4, 5)


def multivalueWithdoubleStar(**x):
    print("Mult - value 2 function")
    # print(x["test"])
    # print(x["test2"])

    print(x.get('name1'))
    print(x.get('name2'))


multivalueWithdoubleStar(name1="Named value 1", name2="Named value 2")



def multivalueWithdoubleStar2(y,**x):
    print("Mult - value 2 function")
    # print(x["test"])
    # print(x["test2"])
    print(y)
    print(x.get('name1'))
    print(x.get('name2'))

multivalueWithdoubleStar2(1,name1="Named value 1", name2="Named value 2")


def firstFunction():
    x = "first function"
    print(x)

    def nestedFunction():
        y = "nested function"
        print(y)

        def innerNest():
            z = "inner nest"
            print(z)

        innerNest()

    nestedFunction()

firstFunction()


