
# Pass statement
for i in range(1,10):
    pass

def test():
    pass




