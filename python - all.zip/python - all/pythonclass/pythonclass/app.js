function test(value){
    switch (value) {
      case 0:
        day = "Sunday";
        break;
      case 1:
        day = "Monday";
        break;
      case 2:
         day = "Tuesday";
        break;
      case 3:
        day = "Wednesday";
        break;
      case 4:
        day = "Thursday";
        break;
      case 5:
        day = "Friday";
        break;
      case 6:
        day = "Saturday";
    }
    return day
}

console.log(test(1))

for (var i=0;i < 10;i++){
    console.log(i)
}

[1,2,3].forEach(function(e){
    console.log(e)
})

var x = 20
function test(){
    x = 10
    console.log(x)
    return x
}

console.log(test())
console.log(x)

function testC(x) {
     return function test(c){
        return x * c
    }
}

console.log(testC(10)(10))

