
def recursion(x):
    if x == 1:
        return 1
    else:
        return  x * recursion(x-1)

#print(recursion(3))


def recussion2Example():
    r = 0
    while r < 10:
        print(r)
        if r == 2 or r ==3 or r == 4:
            recussion2Example()
        r = r + 1


recussion2Example()

