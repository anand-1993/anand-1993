
# Two Scopes
# global
# local

x = 100
def variablesFunction():
    global x
    y = 10
    print(y)
    print("Local Variable")
    x = x + 1
    print(x)

    def nestedFunction():
        global x
        nonlocal y
        x = x + 1
        y = 10 + 10
        print(y)

    nestedFunction()
    print(x)
    print(y)


variablesFunction()
