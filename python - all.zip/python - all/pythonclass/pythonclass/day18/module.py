# Module

# class
# Variable
# Functions.

variable1 = 10
def module1():
    print("Module1")

class Test:

    def t2(self):
        print("Class")