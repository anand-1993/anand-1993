from package1 import pack2,subpackage

#from package1.subPackage.packagemod2 import pack2
pack2()
subpackage()