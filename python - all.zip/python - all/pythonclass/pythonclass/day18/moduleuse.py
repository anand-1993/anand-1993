from module import module1,variable1,Test

#from module import module1,variable1,Test

module1()
print(variable1)

ts = Test();
print(ts.t2())


