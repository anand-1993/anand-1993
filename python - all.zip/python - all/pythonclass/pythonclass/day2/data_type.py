print(" Number Type way 1 -----------------------------------")

aAZ0_ = 10

print(aAZ0_)

print(" Number Type way 2 -----------------------------------")

aBY1_ = int(10)

print(aBY1_)

print("String Type way 1 -----------------------------------")

stringTypeVariable = "String Variable 2"

#print(numberTypeVariable);

# comment. 
# asd 
# ads 
# ads 

'''
as
adsasd
adas
asdasd
adad
dadsad
adasd
'''

print("String Type way 2 -----------------------------------")

stringTypeVariableSecondWay = str("String Variable")

print(stringTypeVariableSecondWay)        


print("Floating Point Values")

floatDataType = 10.10

print(floatDataType)

print("Floating Point Values")

floatDataTypeSecondWay = float(10.1011)

print(floatDataTypeSecondWay)


print("Key Value Pair -----------------------------------")

person_info = { "name" :"pankaj", "age" : "30" }

person_info_2 = dict({ "name1" :"pankaj", "age1" : "30" })

print(person_info)


print(person_info_2)


boolVariable = True

print("Bool First Way")
print(boolVariable)


print("Bool First 2 Way")
boolVariable_2 = bool(False)

print(boolVariable_2)

