#DataTypes
p= "i live in pune"
print("Given String1 is:", p)
print(type(p))
q= True
print(type(q))

#STRING
aString= str("iliveinpune")
print("Given String1 is:", aString)
print(aString.capitalize())

bString= str("I LIVE IN PUNE")
print("Given String2 is:", bString)
print(bString.casefold())

print(aString.count("i"))
print(aString.isalpha())
print(aString.upper())

x= "my name is"
y= " shashank"
z= x+y
print(z)

#DICTIONARY

theDictionary = {
    "Category": "Appliances",
    "BrandList": ["Whirlpool", "BOSCH", "Samsung", "IFB" ],
    "Most Selling Brand": ["Whirlpool", "IFB"],
    "Manuf Year": "2021"
}
print("The given dictionary is:", theDictionary)
print("Length of dict. is:", len(theDictionary))
print(theDictionary.get("Category"))
A = theDictionary["BrandList"]
print(A)
theDictionary["BrandList"].append("LG")
print("Updated dictionary is:", theDictionary)
theDictionary.pop("Manuf Year")
print(theDictionary)

#SET

aSet= {1,2,3}
print(type(aSet))
bSet= {3,4,5,6}
print(aSet|bSet)
print(aSet & bSet)
aSet.remove(2)
print(aSet)
