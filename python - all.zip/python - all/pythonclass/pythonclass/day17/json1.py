import json

#json.dumps()
#json.loads()

# MIME TYPE
# What is JSON

# JavaScript Object Notation : JSON
# JSON is nothing but simple key and value pair
jsonString = '{"name":"python","age":"30","students":[{"name":"test","p":"test"}]}'
pythonDictionary = json.loads(jsonString)

print(pythonDictionary)
print(pythonDictionary.get('name'))

print(type(pythonDictionary))

againJsonString = json.dumps(pythonDictionary)
print(againJsonString)
print(type(againJsonString))
