
# Clousers

def upperFunction(n):
    def nestedFunction(x):
        print(x * n)

    return nestedFunction

#upperFunction(11)(12)

def upperLevelFunction(n):
    n = n
    def nestedLevelFunction(x):
        print(x * n)

    return nestedLevelFunction


level1 =  upperLevelFunction(10)

level1(10)
level1(11)
level1(12)
level1(13)


