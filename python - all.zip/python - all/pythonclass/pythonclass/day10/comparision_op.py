#Equal : ==
#Not Equal: !=
#Greater than: >
#Less than: <
#Greater than or Equal to: >=
#Less than or Equal to: <=

a = 10
b = 20
if a == b:
    print("both are equal : First ")
else:
    print("both are not equal : First")

a = 10
b = 10
if a == b:
    print("both are equal : Second")
else:
    print("both are not equal : Second")

x = 30
y = 40

if x != y:
    print("Both are not equal : Not equal symbol : First")
else:
    print("Both are equal : First")

x = 40
y = 40

if x!= y:
    x = 1
    print("Both are not equal : Not equal symbol : Second ")
else:
    print("Both are equal : Second ")

z = 21
a = 20
if a > z:
    print("a is larger number than z")
else:
    print("a is smaller number than z")

z = 21
a = 22
if a < z:
    print("a is less than z")
    print(a)
else:
    print("a is not less than z")
    print(z)


p = 20
q = 22

if p >= q:
    print("p is grater than q")
    print(p)
else:
    print("p is less than q")
    print(q)

t = 60
s = 60

if t <= s:
    print("Less than block ")
    print(s)
else:
    print("greater than block")
    print(t)


car = {
    "brand" : "Ford",
    "model" : "M",
    "year" : 1666
}

x = car.values()
print("before modification")
print(x)

car['year'] = 2020
print("After modification")
print(x)



z = "21232"
a = "23232"
if a > z:
    print("a is larger number than z")
else:
    print("a is smaller number than z")
