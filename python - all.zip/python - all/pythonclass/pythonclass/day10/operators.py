# Arithmetic operator

#Addition operator
print(10 + 20)

#Substraction operator
print(20 - 5)

# Multiplication
print(10 * 20)

# Division
print(20 / 10)

# Modules used for getting reminder value.
print(11 % 2)
print(12 % 2)

# Increment operator

# 1 way
y = 0
y = y + 1
print(y)

# 2 way
a = 1
a += 1
print(a)


# 1 way
y = 1
y = y - 1
print(y)

# Decrement
a = 1
a -= 1
print(a)





