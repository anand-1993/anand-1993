# print(10 + 20)
#
# print(20 - 10)
#
# print(20*20)
#
# print(20/10)
#
# print(11%2)
#
# a = 10
# a +=1
#
#
# print(a)
# a = 10
# a -=1
# print(a)
#
#
# a = 20
# b = 20
#
# if a < b:
#     print("a less than b")
# else:
#     print("a is larger than b")
#
# if a <= b:
#     print("a less than b")
# else:
#     print("a is larger than b")
#
# if a <= b:
#     print("a less than b")
# else:
#     print("a is larger than b")
#
# a = 20
# b = 20
# if a == b:
#     print("Both numbers are equal")
# else:
#     print("a is larger than b")
#
#
# a = 20
# b = 20
# if a != b:
#     print("Both numbers not are equal")
# else:
#     print("Both numbers are equal")
#
# a = 15
# b = 15
#
# if a >= b:
#     print("a is larger")
# else:
#     print("b is larger")
#
# import datetime
# import math
# import os
x = 20
# def my_func():
#     x = 10
#     print("Value inside function:",x)
#
# #x = 20
# my_func()
# print("Value outside function:",x)

def test(*x,**z):
    #print(x)
   # print(y)
    print(z['x'])
    print(z['y'])
    print(z['z'])
    print("console log")
    return

# test({"test":"test"},x=10,y=10,z=20)


#1. Function recursion
#2.

#1 1*1

# 1*1+ 2*1
# 2
#
def fact(x):
    if x==1:
        return 1
    else:
        return (x * fact(x-1))

print(fact(2))

# Recursive function.
# 
# x = 5
# def foo():
#     x = 10
#     print("local x:", x)
#
# foo()
# print("global x:", x)
#

def outer():
    x = "local"

    def inner():
        nonlocal x
        x = "Pankaj"
        print("inner:", x)

    inner()
    print("outer:", x)


outer()
