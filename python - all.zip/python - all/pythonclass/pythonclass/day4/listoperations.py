
sampleList = [ 1,2,3,4 ]
sampleList1 = list()

# Print List
print(sampleList)
print(sampleList1)

# Positive Index
print(sampleList[1])

# Negative Index
print(sampleList[-4])

# Access using range Index
print(sampleList[1:2])
print(sampleList[1:4])

# calculate the lenght of list
print("List Count")
print(len(sampleList))
print("End  List Count")


# Append to list.
sampleList1.append("string 1")
sampleList1.append("string 2")
sampleList1.append("string 3")
sampleList1.append("string 4")
sampleList1.append("string 5")
sampleList1.append(1)
sampleList1.append({"name" :"pankaj","age" :"30"})
sampleList1.append(1.10)
sampleList1.append(True)

# print sample list
print(sampleList1)
print("End of print")

# Insert will add record at given position
sampleList1.insert(1,"Inserted Object")
print(sampleList1)

# Count the number of occurences
sampleList1.insert(len(sampleList1),"position last Object")
print(sampleList1)
print(sampleList1.count('Inserted Object'))

#
#sampleList1.insert(len(sampleList1),"position last Object")
print(sampleList1.remove(1))
print(sampleList1.remove(1.1))
print(sampleList1.remove("position last Object"))
#print(sampleList1.remove("string 2"))

#print(sampleList1.clear());
copyOfList = sampleList1.copy()

print("Started Pop operation")
print(copyOfList)

copyOfList.pop(len(copyOfList)-1)
print(copyOfList)
print("End pop operation")

print("Reserve order")
copyOfList.reverse()
print(copyOfList)
print("Reserve order ")

sampleList1.extend(sampleList)
# Combine both the Lists
print(sampleList1)
sampleList3 = [10,11,12,13,14]

sampleList1.extend(sampleList3)
print(sampleList1)

sampleTuple = ("kiwi", "orange")
sampleList1.extend(sampleTuple)
print(sampleList1)

sampleList1 = [7,3,6,1]
print(sampleList1.sort())
print(sampleList1)

#sampleList1.




