#Check if 1 is present on list
li = [1,2,3,'a','b','c']
print("Givent list is:",li)
one_is_present= 1 in li
print("1 is present:",one_is_present)

#Create the single list from following list
name = ['Snowball', 'Chewy', 'Bubbles', 'Gruff']
print("Initial List is:", name)
animal = ['Cat', 'Dog', 'Fish', 'Goat']
age = [1, 2, 2, 6]
name.extend([animal, age])
print("List after addtion is:", name)