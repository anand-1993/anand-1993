#tuple to list
tuple = (1,2,3,'name')
print(type(tuple))
x= list(tuple)
print(x)
print(type(x))

# int to float
number= 1
print(type(number))
y= float(number)
print(y)
print("type of y")
print(type(y))

#str to int
a= "1"
print("type of a")
print(type(a))
b=int(a)
print("type of b")
print(type(b))

print("LAst element using negative index")
tupleData = (1,2,3,4,5)
print(tupleData[-1])

print("Print first element from tuple using negative index and positive index")
tupleData = (1,2,3,4,5)
print(tupleData[0])
print(tupleData[-5])

print("find the position of 1 element")
tupleData = (1,2,3,4,5)
print(tupleData.index(1))

print("find the position of 5 element")
tupleData = (1,2,3,4,5)
print(tupleData.index(5))

print("Print tuple in reverse Order")
tupleData = (1,2,3,4,5)
print(tupleData[::-1])

print("Concate tuple using + operator.")
tupleData = (1,2,3,4,5)
tupleData = (1,2,3,4,5)
print(tupleData + tupleData)
