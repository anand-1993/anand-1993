x = 10


thisset = {"apple", "banana", "cherry"}

# For Each loop
for x in thisset:
  print(x)