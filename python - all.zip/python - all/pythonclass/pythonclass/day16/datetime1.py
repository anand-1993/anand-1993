# from datetime import datetime
# #
# print(datetime.day)
import datetime
x = datetime.datetime.now()
print(x)

y = x.date()
print(y)

day = x.day
print(day)

month = x.month
print(month)

print(x.timestamp())

year = x.year
print(year)
print(x.timetz())

# 5.30

# DD/MM/YYYY India
# MM/DD/YYYY US format

# Timezone
# IST +5.30

# GTM +12:00
# UTC +12.00

# Universal time conversion

# import datetime
# import pytz
#
# unaware = datetime.datetime(2011, 8, 15, 8, 15, 12, 0)
# aware = datetime.datetime(2011, 8, 15, 8, 15, 12, 0, pytz.)