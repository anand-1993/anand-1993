import math
import os
import json
import datetime
import csv

print(math.factorial(2))
print(math.floor(10.06))
print(math.ceil(10.04))
print(math.fabs(-1))
print(math.sqrt(64))
print(math.pow(8,2))



