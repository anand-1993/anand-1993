#raise Exception("This is exception")
data = {"firstField" : "1", "secondField" : "string"}
def test():
    print("test")

try:
   print("In exception block")
   test()
   isNumber = data.get("firstField")

   try:
       raise Exception("From Inside Exception")
   except Exception as p:
       print(str(p))

   if isNumber.isnumeric():
       print("Continue")
   else:
       raise Exception("Field is not number")

except ValueError as p:
    print("test")
except NameError as e:
    print("Name eror")
    print(str(e))
except Exception as e:
    print("Generic Error")
    print(str(e))
finally:
    print("In Finally block")


#TRY ->
#Except
#Finally


# Python program to illustrate
# nested functions
x = 10
def outerFunction(num):
    #x = 10
    global x
    def innerFunction():
        return x + 1

    return innerFunction

innerOne = outerFunction(5)

print(innerOne())

# print(innerOne())
#
# print(innerOne())
