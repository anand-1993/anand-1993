# Write program to convert tuple to list
aTuple= ('Bus','car',1,2,3)
aList= list(aTuple)
print(type(aList))
print(aList)

# Write program to convert int to float, str to int
a= 5
print(a)
print(type(a))
b=float(a)
print(b)
print(type(b))

#Print last element from tuple using negative index
tupleData = (1,2,3,4,5)
print("Given Tuple is-",tupleData)
print("Last element is:" ,tupleData[-1])

#Print first element from tuple using negative index and positive index
tupleData = (1,2,3,4,5)
print("Given Tuple is-",tupleData)
print("First element using positive index is:", tupleData[0])
print("First element using negative index is:", tupleData[-5])

#Print tuple in reverse Order
tupleData = (1,2,3,4,5)
print("Given Tuple is-",tupleData)
reversedtupleData= reversed(tupleData)
print("Reverse is:", tuple(reversedtupleData))

#Concate tuple using + operator.
tupleData = (1,2,3,4,5)
tupleData = (1,2,3,4,5)
Concat= tupleData + tupleData
print(Concat)

#write program to define None Type variables.
variable= None
print(type(variable))