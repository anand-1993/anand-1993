
# Implicit Type Conversion...
a = 10

# Implicit Type Conversion... String
b = "Python"

print("Type of A")
print(type(a))

print("Type of B")
print(type(b))


print("Type of B")
print(type(b))

c = ["a",1,2,3]

print("Type of C")
print(type(c))

# Explicit Type Conversion

stringVar = "100"
print("Type of stringVar")
print(type(stringVar))

numberVar = int(stringVar)
print("Type Of Number var")
print(type(numberVar))

print(numberVar)

print("Tuple Type")
tupleType = (1,2,3)
print(type(tupleType))

listType = list(tupleType)

print("List Type")
print(listType)
print(type(listType))

noneType = None
print(noneType)
print(type(noneType))


