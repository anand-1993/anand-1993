tuple = (1,2,3,4)

list = [1,2,3,4]

print("Tuple ")
print(tuple)
print(tuple.__sizeof__())

print("List")
print(list)
print(list.__sizeof__())