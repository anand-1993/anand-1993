tupleData = (1,2,3,4,5)

print(tupleData)

# Access tuple using positive index
print(tupleData[0])

# Access tuple using range index
print(tupleData[0:1])

# Access tuple using range index
print(tupleData[1:3])

# Access using negative Index
print(tupleData[-1])

# Type Casting
tupleData = list(tupleData)
tupleData.append(6)

tupleData = tuple(tupleData)
print(tupleData)

# Join the tuples

tupleData2 = (7,8,9,10,10)
print("tupleData2")
print(tupleData2)

# + operator for join the tuples
mergedTuple = tupleData + tupleData2
print(mergedTuple)

# Method on tuple... count is used to calculate the occurences of element.
print(mergedTuple.count(10))

# Index Method: Index method is used for checking position of that element in the tuple or list or str
print(mergedTuple.index(10))

#print()



