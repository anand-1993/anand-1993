#take input from user
value1 = input("enter your value:")
print(value1)

value2 = input("enter your value:")
print(value2)


print("Addition of two values")
print(int(value1) + int(value2))

print("subtraction of two values")
print(int(value1) - int(value2))

print("multification of two values")
print(int(value1) * int(value2))

print("division of two values")
print(int(value1) / int(value2))
