x,y = input("enter two values : ").split()
# split() is used for diving the content of string into the python list
print(x)
print(y)
print(int(x) + int(y))
print(int(x) - int(y))
print(int(x) * int(y))
print(int(x) / int(y))

#assinging input in program.
x = int(8)
y = float(10.00)
z = float(4.5)
print(x)
print(y)
print(z)

print("Addition of three values :")
print(int(x)+float(y)+int(z))
print("substraction of three values :")
print(int(x)-float(y)-float(z))

###
x1,y2,tupletype,listtype = 10,"python",(4,5,6,8),[1,2,3,4]
print(x1)
print(y2)
print(tupletype)
print(listtype)