p = 101
def variable():
    return p
print(variable())


#print 10 if numberis less than 10 print 20 is number greter than 11
x = 20
if x == 10:
    print(" i am in if block with value 10 ")
    print(x)
if x == 20:
    print("i am in if block with value 20")
    print(x)

if x<1:
    print("print x value 1")
elif x>10:
    print("print value greater than 40")
elif x>20:
    print("print value greater than 40")
elif x>30:
    print("print value greater than 40")
elif x>40:
    print("print value greater than 40")
else:
   print("all false")


print("Completed")
