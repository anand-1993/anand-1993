print('Welcome to python learning')
