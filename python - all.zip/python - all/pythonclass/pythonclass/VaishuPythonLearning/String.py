name = str(" vaishali")
print(name)

name = "vaishali"
print(name.capitalize())

name="VAISHALI"
print(name.casefold())

name="VAISHALI"
print(name.center(100))

name="vaishali"
print(name.center(2

name="I am writting an python string"
print(name.count('i'))

name="I am writting an python string"
print(name.encode())

name = "I am writting an python string"
print(name.endwith("python"))
