import  json
dictionary = {
  "d_mid": "21719812096028661960470805134633783558",
  "id_sync_ttl": 604800,
  "d_blob": "RKhpRz8krg2tLO6pguXWp5olkAcUniQYPHaMWWgdJ3xzPWQmdj0y",
  "dcs_region": 12.000,
  "d_ottl": 7200,
  "ibs": [
    {
      "id": "411",
      "ttl": 10080,
      "tag": "img",
      "fireURLSync": 1,
      "syncOnPage": 1,
      "url": [
        "//cm.everesttech.net/cm/dd?d_uuid=16697069420289241871118918280868145161"
      ]
    }
  ],
  "subdomain": "aws",
  "tid": "W0t7xmaLTW8="
}

print(dictionary)

simpleDictionary = { "name" :"python1","age" : 23, "students":[{ "college" : "s1","place" : "P1" },{ "college" : "s2","place" : "P2" }] }
print(simpleDictionary);

print(simpleDictionary.get("name"))

print(simpleDictionary.get("students"))

listDataType = simpleDictionary.get("students")
listDataType.append({ "college" : "s3","place" : "P2" })

simpleDictionary.update({"students" : listDataType})

print(simpleDictionary)

# Use get alway
print(simpleDictionary.get("value"))
print(simpleDictionary["name"])

simpleDictionary.update({"name1" :"Python2"})

print(simpleDictionary)

# remove operation
print(simpleDictionary.pop('name1'))
print(simpleDictionary)

simpleDictionary1  = simpleDictionary.copy()
print(simpleDictionary1)

simpleDictionary1.clear()
print(simpleDictionary1)

print(simpleDictionary)

keys = simpleDictionary.keys()
print(keys)

values = simpleDictionary.values()
print(values)
tupleData = [1,2,3,4,5,6]
simpleDictionary = simpleDictionary.fromkeys(tupleData,1)

print(simpleDictionary)
print(simpleDictionary.popitem())
print(simpleDictionary)
print(json.dumps(dictionary))

