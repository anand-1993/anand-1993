
set1 = { 1 , 2 ,3 ,4}
set2 = { 1 , 2, 3 , 5}

# Subset : all element from set2 is available in set1 then set2 is called as subset.
print(set2.issubset(set1))

# Superset : S1 is called as superset. beacuse all elements of s2 available in s1
print(set1.issuperset(set2))

# we can use operators on sets.
print("Intersection using logical |")
print(set1 | set2)
#set1.union(set2)

# Intersection
print("Intersection using logical &")
print(set1 & set2)
#set1.intersection(set2)

print("Intersection using logical - ")
print(set2 - set1)

# Common values gets removed and return results.
print(set1.symmetric_difference(set2))
