simpledictionary = { "name1" : "ram" , "age1": 23}
print(simpledictionary)

  #get method is used to accessing the data from dictionary
print(simpledictionary.get("name"))

#update method
simpledictionary.update({"name2" : "sam", "age2": 20})
print(simpledictionary)

#pop/remove data from dictionary
print(simpledictionary.pop("name1"))
print(simpledictionary)


#copy all item
simpledictionary1=simpledictionary.copy()
print(simpledictionary1)


 # clear all data
simpledictionary1.clear()
print(simpledictionary1)

#gives only keys
keys=simpledictionary.keys()
print(keys)


#gives only value
values=simpledictionary.values()
print(values)

# Displays Data as 1:1,2:1 ....so on.
tupledata=(1,2,3,4,5,6)
newdict=dict.fromkeys(tupledata,1)
print(newdict)

# Displays last item from dictionary
print(newdict.popitem())