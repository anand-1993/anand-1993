
numberList = [ 1,2,3,4,5,5,6]

for i in numberList:
    print(i)

dictionary = [ {"name" : "p" ,"age" :"30"},{"name" : "k" ,"age" :"31"}]

for i in dictionary:
    print(i)
    for k in i.values():
        print(k)



breakContinueList = [ 1,2,3,4,5,5,6]

print("Break for loop if we get our result")
# find the 2 element from array
k = None
for i in breakContinueList:
    print(i)
    if i == 3:
        k = i
        break;

print(k)

print("In Find Number")

def findNumber(value):
    k = None
    for i in breakContinueList:
        if i == value:
            k = i
            break;
    return k

print(findNumber(1))

print(findNumber(2))

print(findNumber(10))


# Continue In forloop

k = None
for i in breakContinueList:
    if i == 3:
        k = i
        break
    else:
        if i == 2:
            continue
    print("Number not found in search")

