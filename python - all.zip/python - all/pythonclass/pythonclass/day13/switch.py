v = 10

if v == 10:
    print("True")
elif v == 1:
    print("False")
elif v == 1:
    print("False")
elif v == 1:
    print("False")
elif v == 1:
    print("False")
elif v == 1:
    print("False")
elif v == 1:
    print("False")
elif v == 1:
    print("False")
elif v == 1:
    print("False")
elif v == 1:
    print("False")
elif v == 1:
    print("False")
elif v == 1:
    print("False")
elif v == 1:
    print("False")
elif v == 1:
    print("False")
elif v == 1:
    print("False")
elif v == 1:
    print("False")
elif v == 1:
    print("False")
elif v == 1:
    print("False")
elif v == 1:
    print("False")
elif v == 1:
    print("False")

def zero():
    return "zero"

def one():
    return "one"

def two():
    return "two"

switcher = {
    0: zero,
    1: one,
    2: two
}

def switch_emulate_fn(value):
    # Get the function from switcher dictionary
    func = switcher.get(value, "nothing")
    # Execute the function
    return func()

print(switch_emulate_fn(0))

