for i in range(1,10,5):
    print(i)

