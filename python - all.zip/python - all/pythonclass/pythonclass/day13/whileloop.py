
x = 1
while x < 10:
    x += 1
    print(x)

print("Break Statement # Code")

y = 1

while y < 10:
    y += 1
    if y == 4:
        break
    print(y)


print("Continue in ")

pv = 1
while pv < 5:
    pv += 1

    if pv == 3:
        print("In Continue")
        continue
    print("PV value = ")
    print(pv)





