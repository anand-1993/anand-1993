# Input method is used for taking input from User
value1 = input("Enter your value: ")
print(value1)

value2 = input("Enter your value: ")
print(value2)

print("Addition of two numbers")
print(int(value1) - int(value2))

print("minus of two numbers")
print(int(value1) - int(value2))



