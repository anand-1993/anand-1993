
p = 10

def getVariable():
    p = 10
    return "x"

def getVariable():
    a = 10
    b = 10
    print(a)

# print 10 if number is less than 10 print 20 is number is graten than 11

x = 20

if x != 20:
    print("I am in if block with value 10")
    print(x)
else:
    print("test")

if x == 20:
    print("I am in if block with value 20")
    print(x)

x = 41

if x == 1: # false
    print("Print x value 1")
elif x == 10: #false
    print("print x value grather than 40")
elif x == 20: #false
    print("print x value grather than 40")
elif x == 30: # false
    print("print x value grather than 40")
elif x > 40: # false
    print("print x value grather than 40")
else:
    print("All false")


print("All Done")