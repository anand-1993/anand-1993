
numberList = [1,2,3,4,5,6,10]

p = 10

if p in numberList:
    print("P is available in numberlist")
else:
    print("p is not available in numberlist")


stringList = ["python","php","c#","cpython","nodejs","mongodb"]

language = "php"

if language in stringList:
    print("Available in list",language)
else:
    print("Not available in list",language)

print("Program for Not in")

stringList = ["python","php","c#","cpython","nodejs","mongodb"]

language = "php1"

if language not in stringList:
    print("Not available in list",language)
else:
    print("Available in list", language)
