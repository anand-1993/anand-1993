

p = 20
#
print(p)
print("Add and assign")
p +=1
print(p)

p = 0
for i in range(1,10):
    print(i)
    p += i

print(p)


q = 100
print("Add and assign")
q -=1
print(q)

q = 100
for i in range(1,10):
    print(i)
    q -= i

print(q)


z = 100
print("Z and assign")

z = 1
for i in range(1,10):
    print(i)
    print(z)
    z %= i

print(z)
