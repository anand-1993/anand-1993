
a = 10
b = 10

if a is 10:
    print("Number are equal")

dictionary1 = {"name":"pankaj"}
dictionary2 = {"name":"pankaj"}

if dictionary1 is dictionary2:
    print("Dictionary are equal")
else:
    print("Dictionary location are different event with same value")

dictionary1 = {"name":"pankaj"}
dictionary2 = dictionary1

if dictionary1 is dictionary1:
    print("Dictionary are equal")
else:
    print("Dictionary location are different event with same value")



# IS npt operator

a = 11
b = 10

if a is not 10:
    print("Number are not equal")
else:
    print("Number are equal")

dictionary1 = {"name":"pankaj"}
dictionary2 = {"name":"pankaj"}

if dictionary1 is not dictionary2:
    print("Dictionary location are different event with same value")
else:
    print("Dictionary are equal")

dictionary1 = {"name":"pankaj"}
dictionary2 = dictionary1

if dictionary1 is not dictionary1:
    print("Dictionary location are different event with same value")
else:
    print("Dictionary are equal")


