
# h = 10
# p = 1

# if h == 10:
#     p = 1
# else:
#     p = 2

#print(p)

#p = 10 if h == 10, else 2

h = 11
print("Print in ternary operator")
p = 1 if h==10 else 1
print(p)
