# Usage of module
from module import testModuleFunction
testModuleFunction()

