from helper import  module1Function,module2Function,test1,importVariable
from helper2.mod1 import  mod1Function

#from helper.module1 import importVariable


module1Function()
module2Function()

test1()

print(importVariable)
