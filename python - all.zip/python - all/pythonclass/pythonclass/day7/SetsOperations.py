
#Sets
firstSet = { 1,2,3 ,"4"}
print("Size Of First")
print(firstSet.__sizeof__())
print(firstSet)

firstSet2 = {3,3,3,3,3, 1,2,3 ,3,3,3,3,3,"4"}

print("Size Of Second")
print(firstSet2.__sizeof__())
print(firstSet2)

#
# () tuples are define using ()
# [] lists are define using []
# {} are defined using {}

thirdSet3 = { 1,2,3,4,5,6,7,8,9,10,11}
print(thirdSet3)
thirdSet3.pop()
thirdSet3.pop()
print(thirdSet3)

thirdSet3.add(1)
thirdSet3.add(2)
thirdSet3.add(33)
print(thirdSet3)

findIndex = None
index = 0
for a in thirdSet3:
    if a == 1:
        findElement = index
    index = index + 1

print("Find element")
print(findElement)


print("Printing 4th set")

thirdSet4 = { 1,2,3,4 } #/
thirdSet5 = { 1,2,5,6,7 } #/

commonSet = thirdSet5.intersection(thirdSet4)

print("Common Set")
print(commonSet)


print("Union")

thirdSet6 = { 1,2,3,4 }
thirdSet7 = { 1,2,5,6,7 }

combineAll = thirdSet5.union(thirdSet4)

print("combine All")
print(combineAll)


print("Union")

thirdSet7 = { 1,2,3,4 }
thirdSet7.remove(1)
print(thirdSet7)
thirdSet7.discard(2)
thirdSet7.discard(2)


thirdSet8 = { 1,2,3,4 }
thirdSet9 = { 1,2,5,6,7 }

difference = thirdSet8.difference(thirdSet9)
print("Difference element")
print(difference)

thirdSet8 = { 1,2,3,4 }
thirdSet9 = { 1,2,5,6,7 }

difference = thirdSet9.difference(thirdSet8)
print("Difference element")
print(difference)

copy = thirdSet9.copy()
print(copy)

# Clear will remove all data from sets
thirdSet9.clear()
print(thirdSet9)

thirdSet10 = { 1,2,5,6,7 }
tupleData = { 1,3}

# Extend method..
thirdSet10.update(tupleData)
print(thirdSet10)

print("_trace_trace_trace_trace_trace")

