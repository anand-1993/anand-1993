singleList = [1,2,3,4]
multiList = [1,2,3,4,[8,9,10]]
print(multiList[-1][-1])

tupleList = (1,2,3,4)
tupleList = (1,2,3,4,(8,9,10))
print(tupleList[-1][-1])

multiList.extend(tupleList)
print(multiList)

#["python",(1,2,3,4)]
