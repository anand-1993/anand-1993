
def decorate_function(func):
    def innerFunction(*args):
        print(args)
        depositeAmountValue  = args[0]
        if depositeAmountValue < 500:
            return "Please deposite amount more thanb 500"

        func(args[0])

    return innerFunction

def decorate_function1(func):
    def innerFunction(*args):
        print(args)
        depositeAmountValue  = args[0]
        if depositeAmountValue < 500:
            return "Please deposite amount more thanb 500"

        func(args[0])

    return innerFunction

avaialbeBalance = 100

@decorate_function
def depositeAmount(depositAmount):
    total = avaialbeBalance + depositAmount
    print(total)
    return  total

@decorate_function
def widraw(x):
    print("another function")

print(depositeAmount(510))
