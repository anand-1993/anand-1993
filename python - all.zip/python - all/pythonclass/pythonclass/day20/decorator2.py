
def some_function(func):
    print("Some function")
    print(func())

def test():
    print("print")

some_function(test)


# 2nd

def some_function1(func):
    print("added in list")
    return func

def test1():
    print("Added in the list")

list1 = [1,2]

somevariable = some_function1(test1)

#print(id(somevariable))

list1.append(somevariable)
print(list1[2]())

for i in list1:
    print(id(i))
    #print(type(i))


