import builtins

someVariable = 10
# Global namespace
def exampleNamespace1():
    print("Local namespace")
    x = 10
    # Nested local namespace
    def innerfunction():
        print("Innner function")
        nonlocal x
        x = x + 1

        print(x)



    innerfunction()

exampleNamespace1()

def print(*ags):
    builtins.print("My Own Print")
    x = 10


print("19")
