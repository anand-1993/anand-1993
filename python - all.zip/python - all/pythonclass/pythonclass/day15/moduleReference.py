from module import *
from module2 import someModule2Function as  renameFunction

someModuleFunction()
someModuleFunction2()
renameFunction()


