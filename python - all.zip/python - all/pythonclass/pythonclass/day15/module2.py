
def someModule2Function():
    print("someModule2 Function")


def module2Def():
    print("Module 2 Def")