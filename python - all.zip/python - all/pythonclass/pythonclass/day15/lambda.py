
#lambda [arguments] : expression
#square = lambda x : x * x

sum = lambda x ,y : x + y
mul = lambda x ,y : x * y

print(sum(1,2))
print(mul(1,2))

add = lambda x ,y,z,k,m,p : x + y + z + k + m + p

print(add(1,2,3,4,5,6))

starParameter = lambda *x : print(x)

starParameter(1,2,3,3,3,33,33)

starParameterMul = lambda **x : print(x)

starParameterMul(name="name1",name2="name2")

def test(fn):
    print(fn())

add6 = lambda x,y : x+y

def test1():
    print("Function as Parameter")

test(test1)


