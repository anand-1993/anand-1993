
def someModuleFunction():
    print("someModule Function")

def someModuleFunction2():
    print("someModule Function 2 ")

def someModuleFunction3():
    print("someModule Function 3")