
def factorial(x):
    if x == 1:
        return 1
    else:
        return x * factorial(x-1)

print(factorial(10))

# 1 * 2 * 3 = !3
# 1 * 1 = !1
# 1 * 2 * 3 * 4 = !4


def whileLoop(x):
    while x < 10:
        print(x)
        if x == 2:
            whileLoop(2)
        x += 1

print(whileLoop(1))
