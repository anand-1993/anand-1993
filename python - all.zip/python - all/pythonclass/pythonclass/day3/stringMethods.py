
name = str("Pankaj") # 1
#print(name)
name = "age"  #2 
name = "age1"  #3 

# First Character Capital
name = "pankaj" #1
print(name.capitalize())

# All characters lower case
name = "PANKAJ" #1
print(name.casefold())

# center lower case
name = "PANKAJ" #1
print(name.center(100))

# take at center position
name = "PANKAJ" #1
print(name.center(100))


# count will return number of occurences in string
name = "Run python program for getting count of string python " #1
print(name.count("t"))

# convert into bytes
name = "Run python program for getting count of string python " #1
print(name.encode())

# It return true when program end with that string
name = "Run python program for getting count of string python" #1
print(name.endswith("python"))

# It return true when program end with that string
name = "Run python program for getting count of string python" #1
print(name.endswith("python"))

# It return true when program end with that string
name = "Run python program for getting count of string python" #1
print(name.find("python"))

# Negative Index
#print(name[-20:-1])
name = "Run python program for getting count of string python {0} {1}" #1
print(name.format("Test","Test1"))

name = "Run python program for getting count of string python {0} {1}" #1
print(name.index("python"))


# A-z 0-9
name = "1A1" #1
print(name.isalnum())


# A-Z a-z
name = "AAAAA" #1
print(name.isalpha())


# A-Z a-z
name = "\u0030" #1
print(name.isdecimal())

# A-Z a-z 0-9 _
name = "p09_" #1
print(name.isidentifier())


# A-Z a-z 0-9 _
name = " pankaj" #1
print(name.islower())

myTuple = ("John", "Peter", "Vicky")
x = "&&".join(myTuple)

print(x) 


txt = "I like bananas"
x = txt.replace("bananas", "apples")

print(x) 


txt = "50"
x = txt.zfill(100)

print(x) 

name = "Run python program for getting count of string python" #1
print(name[::-1])

name = "Run python program for getting count of string python" #1
print(name[-10:-20])

# a = "Hello"
# b = "World"
# c = a + b
# print(c)

x,y = input("Enter Name").split()

x = int(x)
y = int(y)

print(x+y)

