
def mod2Function():
    print("Mod2 function")
