
importVariable = 10

def module1Function():
    print("Module 1 function")
