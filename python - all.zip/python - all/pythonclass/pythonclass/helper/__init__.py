from .module1 import module1Function
from .module2 import module2Function
from .subpackage.test import test1
from .module1 import importVariable

#from .module1 import module2Function
