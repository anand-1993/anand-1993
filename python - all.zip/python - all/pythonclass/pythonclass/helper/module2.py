
def module2Function():
    print("Module 2 function")