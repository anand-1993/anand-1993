# Lists are created using square brackets:
# Lists are used to store multiple items in a single variable.
# List items are ordered, changeable, and allow duplicate values.
# List items are indexed, the first item has index [0], the second item has index [1] etc.
# When we say that lists are ordered, it means that the items have a defined order, and that order will not change.
# If you add new items to a list, the new items will be placed at the end of the list.
# Note: There are some list methods that will change the order, but in general: the order of the items will not change.
# The list is changeable, meaning that we can change, add, and remove items in a list after it has been created.
# Since lists are indexed, lists can have items with the same value:
list1 = [13, 54.32, "Music",13, True, False, "Elite", "Nice"]
print(list1)
# To determine how many items a list has, use the len() function:
print(len(list1))
# List items can be of any data type:
# String, int and boolean data types:
boolean = [True, False, False, True, True]
print(boolean)
list1.extend(boolean)
print(list1)
print(type(list1))
# It is also possible to use the list() constructor when creating a new list.
list2 = list((13, 54.32, "Music",13, True, False)) # note the double round-brackets
print(list2)
# List items are indexed and you can access them by referring to the index number:
# Note: The first item has index 0.
print(list2[1])
print(list2[2 : 4 ]) # ranges
# Negative indexing means start from the end
# -1 refers to the last item, -2 refers to the second last item etc.
print(list2[-1])
print(list2[-6 : -2])
# By leaving out the start value, the range will start at the first item:
print(list2[:5])
# By leaving out the end value, the range will go on to the end of the list:
print(list2[3:])
# To determine if a specified item is present in a list use the in keyword:
if "Music" in list2:
    print("yes it is available")
# To change the value of a specific item, refer to the index number:
list2[3] = "Songs"
print(list2)
# To change the value of items within a specific range, define a list with the new values, and
# #refer to the range of index numbers where you want to insert the new values:
list2[2:6] =["Dance", "Gajhal", False, True]
print(list2)
# If you insert more items than you replace, the new items will be inserted where you specified, and the remaining items will move accordingly:
list2[3:5] = [True, "Play"]
print(list2)
# If you insert less items than you replace, the new items will be inserted where you specified, and the remaining items will move accordingly:
list2[4:7] =["rock"]
print(list2)
# To insert a new list item, without replacing any of the existing values, we can use the insert() method.
# The insert() method inserts an item at the specified index:
list2.insert(3, False)
print(list2)
# Note: As a result of the example above, the list will now contain 4 items.

# To add an item to the end of the list, use the append() method:
list2.append("sangit")
print(list2)
# To append elements from another list to the current list, use the extend() method.
list1.extend(list2)
print(list1)
# The extend() >>> you can add any iterable object (tuples, sets, dictionaries etc.).
Tuple = ("piano", "tabla")
list2.extend(Tuple)
print(list2)
# The remove() method removes the specified item.

list1.remove(False)
print(list1)
# The pop() method removes the specified index.
list1.pop(5)
print(list1)
# If you do not specify the index, the pop() method removes the last item.
list1.pop()
print(list1)
# The del keyword also removes the specified index:
del list1[6]
print(list1)
list3 =list1.copy()
print(list3)
list4 = list3.copy()
print(list4)
# The del keyword can also delete the list completely.
del list3
# print(list3) shows error because it is no longer exist
#The clear() method empties the list.
#The list still remains, but it has no content.
list4.clear()
print(list4)
# You can loop through the list items by using a for loop:
# items will be presented one by one
for x in list2:
    print(x)

# Loop Through the Index Numbers
# You can also loop through the list items by referring to their index number.
# Use the range() and len() functions to create a suitable iterable.
# The iterable created in the example above is [0, 1, 2].
for x in range(len(list2)):
 print(list2[x])
 # Using a While Loop
 i = 0
 while i < len(list2):
     print(list2[i])
     i = i+1
# A short hand for loop that will print all items in a list:
print((x) for x in list2)
#List comprehension offers a shorter syntax when you want to create a new list based on the values of an existing list.
# Example:
# Based on a list of fruits, you want a new list, containing only the fruits with the letter "a" in the name.
list5 = ["sagar", "Nikhil", "javed", "Mla"]
newlist= []
for t in list5:
    if "a"  in t:
        newlist.append(t)
        print(newlist)
# Without list comprehension you will have to write a for statement with a conditional test inside:
newlist1 = ( x for x in list5 if "a" in x)
print(newlist1)
newlist1 = [x.upper() for x in list5]
print(newlist1)

# List objects have a sort() method that will sort the list alphanumerically, ascending, by default:
print(list5.sort())
print(list5)
# To sort descending, use the keyword argument reverse = True:
print(list5.sort(reverse=True))
print(list5)
# By default the sort() method is case sensitive, resulting in all capital letters being sorted before lower case letters:
list5.sort()
print(list5)

# Luckily we can use built-in functions as key functions when sorting a list.
# So if you want a case-insensitive sort function, use str.lower as a key function:
list5.sort(key = str.lower)
print(list5)
# The reverse() method reverses the current sorting order of the elements.
list5.reverse()
print(list5)
# making copy
list6 = list5.copy()
print(list6)
# another way making copy using list()
list7 = list(list6)
print(list7)
# There are several ways to join, or concatenate, two or more lists in Python.
# One of the easiest ways are by using the + operator.
list7 = list1 + list7
print(list7)
# Another way to join two lists is by appending all the items from list2 into list1, one by one:
numlist = [10,23,58,63]
for x in list6:
    numlist.append(x)
print(numlist)
# count()>> Return the number of times the value  appears in the  list:
x = list7.count(13)
print(z)