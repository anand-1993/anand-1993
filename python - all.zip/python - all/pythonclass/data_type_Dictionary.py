print("Number Type way 1-----------")
aSt_= 10
print(aSt_)
print("String VType way1-------")
stringTypeVariable = "String VAriable 2"
print(stringTypeVariable)
# dkjflskjdlf
# gsdfvdkflgk
"""shdkjfhlaksdjfknmn,mnxkcjv

 dfgdsfgdsfgdfgjl"""

print("String type way 2")
stringTypeVariableSecond = str("strin Variable")
print(stringTypeVariableSecond)
print("floating Point value")
floatDataType = 50.36
print(floatDataType)
print("float second way")
floatSecondWay = float(56.36)
print(floatSecondWay)

#  DICTIONARY START @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
data = {"name":"Anand" , "Prof":"Engineer" , "age":30}
print(data)
# Accessing values of keys
print(data["name"])
# to know number of items in dictionary
print(len(data))
# dictionary key values may have any data type like sting, int, boolean,list, float
data1 ={"Fruit" : "Mango", 1993 : "birth_year" ,"Vegetable" : False, "Application":["shake", "candy"]}

print(data1)
print(type(data1))
# Using get() can access key value from dictionay
print(data1.get(1993))
# getting a list of all keys in from dictionary
print(data1.keys())

# Add a new item to the original dictionary, and see that the keys list gets updated as well
print("before adding items dictionary is")
print(data1.keys())
data1["color"] = "Green"
print("after adding items color , dictionary is")
print(data1.keys())

# The values() method will return a list of all the values in the dictionary.
print(data1.values())
# making changes in values
data1["Fruit"] = "Orange"
print(data1)
# another way
x = data1.values()
data1["Fruit"] = "banana"
print(x)
print(data1)
# getting a list of all keys as tuple item() method is used
print(data1.items())
# Aanother way
y = data1.items()
print(y)
# check if key Exist
if "Vegetable" in data1:
    print(" Yes Vegetable is one of keys in the data1 dictionary")
# to update dictionary with key value pair update() used.
data1.update({"Vegetable" : "Curry"})
data1.update({"Milk" : "Banana_milk"})
print(data1)
# removing items from a dictionary pop()- removes key value paired using specified key
data1.pop("Milk")
print(data1)
# popitem() removes the last inserted item
data1.popitem()
print(data1)
# clear() empties the dictionary
# del keyword used to delete the item with specified key name
# del keyword also delete the dictionary completely and shows error because "data3" no longer exist
data3 = {"name":"Anand","Prof":"Engineer","age":30}
data3.clear()
print(data3)
# del keyword used to delete the item with specified key name
# del keyword also delete the dictionary completely and shows error because "data3 is no longer
data4 = {"name":"Anand","Prof":"Engineer","age":30}
del data4["Prof"]

print(data4)
# del data4
print(data4)
# to print all keys from dictionary one by one using for loop
data5 = {"name":"Anand","Prof":"Engineer","age":30}
for t in data5:
    print(t)
    # using key() method
for s in data5.keys():
    print(s)
    # using values() method
for s in data5.values():
    print(s)
# loop through items() method
for s,t in data5.items():
    print(s,t)
# making copy of dictionary in variable
data6 ={"Fruit" : "Mango", 1993 : "birth_year" ,"Vegetable" : False, "Application":["shake", "candy"]}
Duplicate = data6.copy()
print(Duplicate)
# Another{'Fruit': 'Mango way to make a copy is to use the built-in function dict().
dup1 = dict.keys(data6)
print(dup1)
# Nested Dictionary- A dictionary can contain dictionaries, this is called nested dictionaries.
All_data = { "data1" : {"name" : "Anand","Prof" : "Engineer", "age" : 30},
             "data2" : {"Fruit" : "Mango", 1993 : "birth_year" ,"Vegetable" : False, "Application":["shake", "candy"]}
           }
print(All_data)
# Create two dictionaries, then create one dictionary that will contain the other three dictionaries:
data7 = {"name":"Anand","Prof":"Engineer","age":30}
data8 ={"Fruit" : "Mango", 1993 : "birth_year" ,"Vegetable" : False, "Application":["shake", "candy"]}
Diction = {"data7" : data7, "data8" : data7}
print(Diction)

# setdefault()	Returns the value of the specified key. If the key does not exist: insert the key, with the specified value
data20 = {"name":"Anand","Prof":"Engineer","age":30}
x = data20.setdefault("name","amol")
print(x)

# keys	Required. An iterable specifying the keys of the new dictionary
# value	Optional. The value for all keys. Default value is None
lang = ('java', 'php', 'python')
allow = "User_Inteface"
mode = dict.fromkeys(lang,allow)
print(mode)
mode1 = dict.fromkeys(lang)
print(mode1)



#~~~~Python has a set of built-in methods that you can use on dictionaries.

"""Method	Description
clear()	>>Removes all the elements from the dictionary
copy()	>>Returns a copy of the dictionary
fromkeys()	>>Returns a dictionary with the specified keys and value
get()	>>Returns the value of the specified key
items()	>>Returns a list containing a tuple for each key value pair
keys()	>>Returns a list containing the dictionary's keys
pop()	>>Removes the element with the specified key
popitem()	>>Removes the last inserted key-value pair
setdefault()	>>Returns the value of the specified key. If the key does not exist: insert the key, with the specified value
update()	>>Updates the dictionary with the specified key-value pairs
values()	>>Returns a list of all the"""
# DIitemsCTIONARY END @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@2