"""Tuple
Tuples are used to store multiple items in a single variable.

Tuple is one of 4 built-in data types in Python used to store collections of data, the other 3 are List, Set, and Dictionary, all with different qualities and usage.

A tuple is a collection which is ordered and unchangeable.

Tuples are written with round brackets."""
tuple = ("input", "output", "execute", "input")
print(tuple)
# Tuple items are ordered, unchangeable, and allow duplicate values.
# Tuple items are indexed, the first item has index [0], the second item has index [1] etc.
# When we say that tuples are ordered, it means that the items have a defined order, and that order will not change.
# Tuples are unchangeable, meaning that we cannot change, add or remove items after the tuple has been created.
# Since tuples are indexed, they can have items with the same value:

# To determine how many items a tuple has, use the len() function:
print(len(tuple))

# To create a tuple with only one item, you have to add a comma after the item, otherwise Python will not recognize it as a tuple.
tuple1 = ("akash",)
print(tuple1)
# not a tuple if comma is not given
tup = ("rajesh")
print(type(tup))

# Tuple items can be of any data type: String, int and boolean data types:
tup1 = ("amol", 100, 52.63, True, False,)
print(tup1)
print(type(tup1))
# You can access tuple items by referring to the index number, inside square brackets:
print(tup1[1])
# Negative indexing means start from the end.
# -1 refers to the last item, -2 refers to the second last item etc.
print(tup1[2])
print(tup1[2:5])
# By leaving out the start value, the range will start at the first item:
print(tup1[:5])
# By leaving out the end value, the range will go on to the end of the list:
print(tup1[2:])
# Specify negative indexes if you want to start the search from the end of the tuple:
print(tup1[-5 : -1]) ##Negative indexing means starting from the end of the tuple.

#This example returns the items from index -4 (included) to index -1 (excluded)

#Remember that the last item has the index -1,

# To determine if a specified item is present in a tuple use the in keyword:
if 100 in tup1:
    print("yes it si available")
# Once a tuple is created, you cannot change its values. Tuples are unchangeable, or immutable as it also is called.
# But there is a workaround. You can convert the tuple into a list, change the list, and convert the list back into a tuple..
tup2 = ("True", 500, "Som")
list1 = list(tup2)
print(list1)
list1[0] = "Anand"
# tup2 = tuple(list1)
# print(tup2)
# Add tuple to a tuple. You are allowed to add tuples to tuples,
# so if you want to add one item, (or many), create a new tuple
# with the item(s), and add it to the existing tuple:
tup1 += tup2
print(tup1)

# The del keyword can delete the tuple completely:
thistuple = ("apple", "banana", "cherry")
del thistuple
# print(thistuple)     #this will raise an error because the tuple no longer exist
# When we create a tuple, we normally assign values to it. This is called "packing" a tuple:
tup3 = ("Anand", "30", "Eng")
print(tup3)

# But, in Python, we are also allowed to extract the values back into variables. This is called "unpacking":
(Name, Age, Prof) = tup3
print(Name, Age, Prof)
# Note: The number of variables must match the number of values in the tuple, if not, you must use an asterisk to collect the remaining values as a list.
(Name, *Age) = tup3
print(Name, Age)
# If the asterisk is added to another variable name than the last,
# Python will assign values to the variable until the number of values left matches the number of variables left.
tup4 = ("Keyboard", "Monitor", "Python", 3, "aws")
(Input, *output, Lang) = tup4
print(Input, output, Lang)
# You can loop through the tuple items by using a for loop.
for x in tup4:
    print(x)
for i in range(len(tup4)):
    print(tup4[i])
# Print all items, using a while loop to go through all the index numbers:
i = 0
while i < len(tup4):
    print(tup4[i])
    i= i+1
# To join two or more tuples you can use the + operator:
tuple5 =tup3+tup1+tup4
print(tuple5)
# If you want to multiply the content of a tuple a given number of times, you can use the * operator:
mulT = tup4*2
print(mulT)
# count()	Returns the number of times a specified value occurs in a tuple
print(mulT.count("aws"))
# index()	Searches the tuple for a specified value and returns the position of where it was found
x = mulT.index("aws")
print(x)
