# User Input
# uses the input() method.
#Myname = input("Enter Your Name ")
#print("My name is " +Myname)
# Python stops executing when it comes to the input() function, and continues when the user has given some input.
#value1 = input("Enter your value: ")
#print(value1)

#value2 = input("Enter your value: ")
#print(value2)

#print("Addition of two numbers")
#print(int(value1) - int(value2))

#print("minus of two numbers")
#print(int(value1) - int(value2))
# # Take multiple inputs from Use
# # Take multiple inputs from Use
# x, y = input("Enter two values").split()
# list = list((input("Enter items in a list").split()))
# print(list)
