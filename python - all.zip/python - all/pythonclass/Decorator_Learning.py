def cam():
    if val() < 0:
        return print("negative number")
    elif val() % 2 == 0:
        return print("Even number")
    else:
        return print("odd number")


@cam
def val():
    print("enter number")
    x = int(input())
    return x


print(val())
