# define one list and swap the position of the list
# 3 -1
"""list1 = [10, 23, 56, 58, 47]
temp = 0
temp = list1[0]
list1[0] = list1[4]
list1[4] = temp
print(list1)
word = "i am anand kumar som".split()
new = ""
# for i in range(len(word)):
for i in word:
    if len(i) % 2 == 0:
        new = " " + i
print(new)
# define two sets and do intersection and unione of both the sets
set1 = {45, 65, 12, 75, 48, 98}
set2 = {12, 55, 74, 96, 21, 74}
print(set1.intersection(set2))
print(set1.union(set2))

# addition two of numbera without using + operator
x = 60
y = 40
sum1 = [x, y]
print(sum(sum1))"""
str1 = "anand"
str2 = "kumar"
str1.removeprefix()
print(str1)
